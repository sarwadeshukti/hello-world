# Secure Client Application

Rust WASM client with AES-256-GCM decryption capabilities.

## Setup Instructions

1. Prerequisites:
   - Rust and Cargo (latest stable)
   - wasm-pack
   - Python 3 (for local server)

2. Install wasm-pack:
```bash
curl https://rustwasm.github.io/wasm-pack/installer/init.sh -sSf | sh
```

3. Build Project:
```bash
wasm-pack build --target web
```

4. Run Local Server:
```bash
python -m http.server 8000
```

## Project Structure
```
src/
├── lib.rs              # Main WASM module
└── models.rs           # Data models
Cargo.toml             # Rust dependencies
index.html             # Test page
```

## Development

1. Main Components:
   - `SecureClient`: Handles encryption/decryption
   - Login functionality
   - Person details retrieval

2. Building for Development:
```bash
wasm-pack build --target web --dev
```

3. Testing:
```bash
wasm-pack test --chrome
```

## Dependencies
Check `Cargo.toml` for complete list:
- wasm-bindgen
- aes-gcm
- base64
- serde