package api.service;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.springframework.stereotype.Service;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.Security;
import java.util.Base64;

@Service
public class CryptoService {
    private static final int KEY_SIZE = 32; // 256-bit key for AES-256
    private static final int NONCE_SIZE = 12; // 96-bit nonce for GCM
    private static final int TAG_LENGTH_BIT = 128; // 128-bit authentication tag
    private static final String ALGORITHM = "AES/GCM/NoPadding";
    private final SecureRandom secureRandom;

    static {
        // Ensure BouncyCastle provider is added once for AES support
        if (Security.getProvider(BouncyCastleProvider.PROVIDER_NAME) == null) {
            Security.addProvider(new BouncyCastleProvider());
        }
    }

    public CryptoService() {
        this.secureRandom = new SecureRandom();
    }

    // Generate a 256-bit AES encryption key
    public String generateEncryptionKey() {
        byte[] key = new byte[KEY_SIZE];
        secureRandom.nextBytes(key);
        return Base64.getEncoder().encodeToString(key);
    }

    // Encrypt data using AES-256-GCM
    public String encrypt(String data, String keyBase64) throws Exception {
        byte[] keyBytes = Base64.getDecoder().decode(keyBase64);

        // Validate key size
        if (keyBytes.length != KEY_SIZE) {
            throw new IllegalArgumentException("Invalid key size. Expected " + KEY_SIZE + " bytes.");
        }

        // Generate a new nonce for each encryption operation
        byte[] nonce = new byte[NONCE_SIZE];
        secureRandom.nextBytes(nonce);

        // Initialize AES cipher in GCM mode
        SecretKey key = new SecretKeySpec(keyBytes, "AES");
        Cipher cipher = Cipher.getInstance(ALGORITHM, BouncyCastleProvider.PROVIDER_NAME);

        GCMParameterSpec gcmSpec = new GCMParameterSpec(TAG_LENGTH_BIT, nonce);
        cipher.init(Cipher.ENCRYPT_MODE, key, gcmSpec);

        // Encrypt the data
        byte[] encryptedData = cipher.doFinal(data.getBytes(StandardCharsets.UTF_8));

        // Combine nonce and encrypted data for easy transmission
        byte[] combined = new byte[nonce.length + encryptedData.length];
        System.arraycopy(nonce, 0, combined, 0, nonce.length);
        System.arraycopy(encryptedData, 0, combined, nonce.length, encryptedData.length);

        return Base64.getEncoder().encodeToString(combined);
    }

    // Decrypt data using AES-256-GCM
    public String decrypt(String encryptedDataBase64, String keyBase64) throws Exception {
        byte[] combined = Base64.getDecoder().decode(encryptedDataBase64);
        byte[] keyBytes = Base64.getDecoder().decode(keyBase64);

        // Validate key size
        if (keyBytes.length != KEY_SIZE) {
            throw new IllegalArgumentException("Invalid key size. Expected " + KEY_SIZE + " bytes.");
        }

        if (combined.length < NONCE_SIZE) {
            throw new IllegalArgumentException("Invalid encrypted data format.");
        }

        // Separate nonce and ciphertext
        byte[] nonce = new byte[NONCE_SIZE];
        byte[] ciphertext = new byte[combined.length - NONCE_SIZE];
        System.arraycopy(combined, 0, nonce, 0, NONCE_SIZE);
        System.arraycopy(combined, NONCE_SIZE, ciphertext, 0, ciphertext.length);

        // Initialize AES cipher in GCM mode for decryption
        SecretKey key = new SecretKeySpec(keyBytes, "AES");
        Cipher cipher = Cipher.getInstance(ALGORITHM, BouncyCastleProvider.PROVIDER_NAME);

        GCMParameterSpec gcmSpec = new GCMParameterSpec(TAG_LENGTH_BIT, nonce);
        cipher.init(Cipher.DECRYPT_MODE, key, gcmSpec);

        // Decrypt the data
        byte[] decryptedData = cipher.doFinal(ciphertext);
        return new String(decryptedData, StandardCharsets.UTF_8);
    }

    // Main method to test encryption and decryption
    public static void main(String[] args) {
        try {
            CryptoService cryptoService = new CryptoService();

            // Generate a new encryption key
            String keyBase64 = cryptoService.generateEncryptionKey();
            System.out.println("Generated Key (Base64): " + keyBase64);

            // Original message to encrypt
            String originalMessage = "This is a secret message!";
            System.out.println("Original Message: " + originalMessage);

            // Encrypt the message
            String encryptedMessage = cryptoService.encrypt(originalMessage, keyBase64);
            System.out.println("Encrypted Message (Base64): " + encryptedMessage);

            // Decrypt the message
            String decryptedMessage = cryptoService.decrypt(encryptedMessage, keyBase64);
            System.out.println("Decrypted Message: " + decryptedMessage);

            // Verify if the original message and decrypted message are the same
            if (originalMessage.equals(decryptedMessage)) {
                System.out.println("Encryption and decryption are working correctly!");
            } else {
                System.out.println("There is an issue with encryption or decryption.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
