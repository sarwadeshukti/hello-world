import os
import yaml
from fastapi import FastAPI, HTTPException

app = FastAPI(title="IDP Config & Template Service", version="4.0")
CONFIG_ROOT = os.getenv("CONFIG_ROOT_DIR", "/etc/idp/config")

@app.get("/healthz")
def healthz():
    return {"status": "healthy", "service": "config-template-service"}

@app.get("/v1/config/tenants/{tenant_id}")
def get_tenant_config(tenant_id: str):
    path = os.path.join(CONFIG_ROOT, "tenants", f"{tenant_id}.yaml")
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Tenant config not found")
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

@app.get("/v1/templates/{scope}/{template_id}")
def get_template(scope: str, template_id: str, tenant_id: str = None):
    if scope.upper() == "GLOBAL":
        path = os.path.join(CONFIG_ROOT, "templates", "global", f"{template_id}.yaml")
    elif scope.upper() == "TENANT" and tenant_id:
        path = os.path.join(CONFIG_ROOT, "templates", "tenants", tenant_id, f"{template_id}.yaml")
    else:
        raise HTTPException(status_code=400, detail="Invalid scope or missing tenant_id")

    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Template not found")
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)
