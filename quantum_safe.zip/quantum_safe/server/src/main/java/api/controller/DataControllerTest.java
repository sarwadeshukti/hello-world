package api.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import api.model.Person;
import api.service.CryptoService;
import api.service.SessionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

class DataControllerTest {
    @Mock
    private SessionService sessionService;

    @Mock
    private CryptoService cryptoService;

    private DataController dataController;
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        objectMapper = new ObjectMapper();
        dataController = new DataController(sessionService, cryptoService);

        when(sessionService.isValidSession("valid-session")).thenReturn(true);
        when(sessionService.getEncryptionKey("valid-session")).thenReturn("test-key");
    }

    @Test
    void testGetPersonDetailsWithValidSession() throws Exception {
        // Given
        when(cryptoService.encrypt(anyString(), eq("test-key")))
                .thenReturn("encrypted-data");

        // When
        ResponseEntity<String> response = dataController.getPersonDetails("valid-session");

        // Then
        assertTrue(response.getStatusCode().is2xxSuccessful());
        assertEquals("encrypted-data", response.getBody());
        verify(cryptoService).encrypt(anyString(), eq("test-key"));
    }

    @Test
    void testGetPersonDetailsWithInvalidSession() throws Exception {
        // When
        ResponseEntity<String> response = dataController.getPersonDetails("invalid-session");

        // Then
        assertTrue(response.getStatusCode().is4xxClientError());
        verifyNoInteractions(cryptoService);
    }

    @Test
    void testGetNearestBranch() {
        // When
        ResponseEntity<String> response = dataController.getNearestBranch();

        // Then
        assertTrue(response.getStatusCode().is2xxSuccessful());
        assertEquals("456 Branch St, City", response.getBody());
    }
}
