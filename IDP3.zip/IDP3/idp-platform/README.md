# Enterprise API-First Intelligent Document Processing (IDP) & Hybrid OCR Platform (v4.0)

A high-performance, cloud-native, multi-tenant IDP platform supporting Tri-Track Hybrid Compute (Digital-Native Bypass, CPU Fast-Track, and Hyper-Parallel GPU VLM Map-Reduce with Seam Strips).

## Project Structure

```text
idp-platform/
├── deploy/
│   ├── docker-compose.yml                 # Local Docker Desktop stack (Infinispan, Kafka, MinIO, Oracle 19c, Services)
│   └── openshift/                         # OpenShift manifests / Helm charts
├── config/                                # Phase 1 File-Based Configs
│   ├── platform.yaml
│   ├── tenants/
│   │   └── tnt_maharashtra_fin_01.yaml
│   └── templates/
│       ├── global/
│       │   └── kyc_base_v1.yaml
│       └── tenants/
│           └── tnt_maharashtra_fin_01/
│               └── agri_loan_multipage_v1.yaml
├── proto/                                 # gRPC Protobuf contracts
│   ├── ingestion.proto
│   ├── worker_inference.proto
│   └── telemetry.proto
├── services/
│   ├── api-gateway/                       # Edge gateway & rate limiter
│   ├── config-template-service/           # YAML loader & Data Grid cache
│   ├── splitter-router-service/           # C++ pdfium bindings & Seam Gatekeeper
│   ├── cpu-ocr-worker/                    # ONNX / OpenVINO INT8 OCR
│   ├── gpu-vlm-worker/                    # vLLM / HF client & FSM guided decoding
│   ├── reduce-storage-service/            # Cross-page stitcher & PII redactor
│   └── telemetry-service/                 # Step telemetry API
└── db/
    └── migrations/
        └── V1__oracle_19c_phase2_schema.sql # Oracle 19c DDL migration
```

## Running Locally with Docker Compose

1. Start the stack:
   ```bash
   cd deploy
   docker compose up --build -d
   ```

2. Test API Extraction (Variations):

   - **Variation 1: Basic Extraction (Tenant Header & PDF File)**
     ```bash
     curl -X POST http://localhost:8080/v1/documents/extract \
       -H "X-Tenant-ID: tnt_maharashtra_fin_01" \
       -F "file=@sample.pdf"
     ```

   - **Variation 2: Extraction with Custom Template Options**
     ```bash
     curl -X POST http://localhost:8080/v1/documents/extract \
       -H "X-Tenant-ID: tnt_maharashtra_fin_01" \
       -F "file=@sample.pdf" \
       -F "options={\"template_id\": \"agri_loan_multipage_v1\"}"
     ```

   - **Variation 3: Extraction with Idempotency Key & Authorization Headers**
     ```bash
     curl -X POST http://localhost:8080/v1/documents/extract \
       -H "X-Tenant-ID: tnt_maharashtra_fin_01" \
       -H "X-Idempotency-Key: idemp_key_12345" \
       -H "Authorization: Bearer secret_token_xyz" \
       -F "file=@sample.pdf"
     ```

   - **Variation 4: Extraction with Extraction Schema Override**
     ```bash
     curl -X POST http://localhost:8080/v1/documents/extract \
       -H "X-Tenant-ID: tnt_maharashtra_fin_01" \
       -F "file=@sample.pdf" \
       -F "extraction_schema_override={\"fields\": [\"pan_number\", \"applicant_name\"]}"
     ```

3. Query Step Telemetry:
   ```bash
   curl http://localhost:8081/v1/telemetry/jobs/{job_id} \
     -H "X-Tenant-ID: tnt_maharashtra_fin_01"
   ```
