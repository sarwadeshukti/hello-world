# Enterprise IDP Platform v4.0 — Step-by-Step Configuration Guide

This guide details how to configure tenants, platform infrastructure parameters, global extraction schemas, and tenant-specific template inheritance within the Enterprise Intelligent Document Processing (IDP) Platform v4.0.

---

## Architecture of the Configuration Backbone

The platform supports a dual-phase configuration strategy:
1. **Phase 1 (Active)**: File-based YAML configuration tree located at `/etc/idp/config` (mounted in Docker as `config/`). Supports automatic file watching and Hot Rod L1 Near-Cache synchronization in Red Hat Data Grid (Infinispan).
2. **Phase 2 (Ready)**: Oracle Database 19c SecureFiles `BLOB` with `CHECK (EXTRACTED_JSON IS JSON)` constraints (`db/migrations/V1__oracle_19c_phase2_schema.sql`).

---

## Step 1: Platform-Wide Infrastructure Configuration (`config/platform.yaml`)

The platform configuration governs global environment settings, data grid (Infinispan) clusters, L1 near-cache sizing, and Apache Kafka topic routing.

### Example File: `config/platform.yaml`
```yaml
apiVersion: idp.enterprise.in/v4
kind: PlatformConfiguration
spec:
  environment: "production" # "local-docker" | "openshift-prod"
  config_provider:
    backend: "FILE_YAML"    # "FILE_YAML" (Phase 1) | "ORACLE_DB" (Phase 2)
    file_watch_enabled: true
    config_root_dir: "/etc/idp/config"
  datagrid:
    hotrod_servers: "datagrid-cluster.idp-infra.svc.cluster.local:11222"
    l1_nearcache_enabled: true
    l1_max_entries: 5000
    caches:
      tenant_config: "idp-tenant-config-cache"
      schema_fsm: "idp-schema-fsm-cache"
      ratelimit: "idp-ratelimit-counters"
      page_mapreduce: "idp-page-mapreduce-cache"
      telemetry: "idp-job-telemetry-cache"
      write_behind_storage: "idp-write-behind-storage-cache"
  kafka:
    bootstrap_servers: "amq-streams-kafka-bootstrap.idp-infra.svc.cluster.local:9092"
    topics:
      gpu_vlm_jobs: "idp.jobs.gpu.vlm"
      telemetry_events: "idp.telemetry.steps"
      storage_write_behind: "idp.storage.writebehind"
```

---

## Step 2: Tenant-Specific Configuration (`config/tenants/<tenant_id>.yaml`)

Each tenant has an isolated configuration file defining rate limits, storage policies (Red Hat ODF, MinIO S3, Oracle DB, or Memory), compute defaults, VLM endpoints, and webhook dispatch URLs.

### Example File: `config/tenants/tnt_maharashtra_fin_01.yaml`
```yaml
apiVersion: idp.enterprise.in/v4
kind: TenantConfiguration
metadata:
  tenant_id: "tnt_maharashtra_fin_01"
  tenant_name: "Maharashtra Rural Finance Corp"
  status: "ACTIVE"
spec:
  rate_limits:
    requests_per_second: 250
    max_concurrent_vlm_pages: 64
  storage_policy:
    primary_backend: "REDHAT_ODF" # Options: REDHAT_ODF | MINIO_S3 | ORACLE_DB | MEMORY_ONLY
    write_mode: "ASYNC_WRITE_BEHIND" # "ASYNC_WRITE_BEHIND" | "STRICT_SYNC"
    retention_days: 90
    redhat_odf_config:
      endpoint: "https://s3-openshift-storage.apps.ocp.enterprise.in"
      bucket_name: "idp-tnt-mh-fin-01"
      region: "ap-south-1"
    minio_config:
      endpoint: "http://minio:9000"
      bucket_name: "local-idp-tnt-mh-fin-01"
    oracle_db_config:
      db_version: "19c"
      jdbc_url: "jdbc:oracle:thin:@//oracle19c-prod.enterprise.in:1521/IDPPDB1"
      lob_prefetch_size_bytes: 262144
      blob_table: "IDP_DOCUMENT_BLOBS"
      json_table: "IDP_EXTRACTION_RESULTS"
  compute_defaults:
    default_compute_tier: "AUTO"
    enable_digital_native_bypass: true
    enable_per_page_hybrid_routing: true
    enable_conditional_seam_strips: true
    vlm_config:
      default_provider: "vllm" # "vllm" | "huggingface"
      vllm_endpoint: "http://vllm-qwen25-vl.idp-gpu.svc.cluster.local:8000"
      default_model_id: "Qwen/Qwen2.5-VL-7B-Instruct"
      enable_compact_tuple_tables: true
  webhooks:
    on_completion_url: "https://erp.mahafin.in/api/v1/idp/webhook"
    hmac_secret_env_var: "WEBHOOK_SECRET_TNT_MH_01"
```

---

## Step 3: Global Base Extraction Templates (`config/templates/global/<template_name>.yaml`)

Global templates define enterprise-wide foundational fields, multilingual normalization rules, and PII masking policies.

### Example File: `config/templates/global/kyc_base_v1.yaml`
```yaml
apiVersion: idp.enterprise.in/v4
kind: ExtractionTemplate
metadata:
  template_id: "kyc_base_v1"
  scope: "GLOBAL"
  owner_tenant_id: null
spec:
  compute_tier: "CPU_FAST"
  languages: ["en", "hi", "mr", "ta"]
  additional_prompt: "Extract official Indian KYC fields accurately. Normalize all dates to YYYY-MM-DD."
  schema:
    fields:
      applicant_name:
        type: "string"
        description: "Full name of the individual"
        required: true
      pan_number:
        type: "string"
        description: "10-character alphanumeric PAN"
        regex: "^[A-Z]{5}[0-9]{4}[A-Z]{1}$"
        required: false
      government_uid:
        type: "string"
        description: "National identity number if present"
        mask_pii: "REDACT"
        required: false
      date_of_birth:
        type: "date"
        format: "YYYY-MM-DD"
        required: false
```

---

## Step 4: Tenant-Specific Inheritance Extraction Templates (`config/templates/tenants/<tenant_id>/<template_name>.yaml`)

Tenant templates inherit from global base templates (`extends_template`) and add specialized schema definitions, cross-page continuation rules, and custom prompts.

### Example File: `config/templates/tenants/tnt_maharashtra_fin_01/agri_loan_multipage_v1.yaml`
```yaml
apiVersion: idp.enterprise.in/v4
kind: ExtractionTemplate
metadata:
  template_id: "agri_loan_multipage_v1"
  scope: "TENANT"
  owner_tenant_id: "tnt_maharashtra_fin_01"
  extends_template: "global:kyc_base_v1"
spec:
  compute_tier: "AUTO"
  languages: ["en", "mr", "hi"]
  multipage_config:
    enable_cross_page_continuation: true
    conditional_seam_gatekeeper: true
    seam_overlap_ratio: 0.15
  additional_prompt: >
    Multi-page Marathi and English agricultural loan form. Land survey tables
    (Gat / Survey numbers) frequently split across pages without repeating headers;
    merge all rows into `land_holdings`. Concatenate `property_address` if split across page breaks.
    Convert Devanagari numerals to standard Western Arabic numerals.
  schema:
    fields:
      property_address:
        type: "string"
        description: "Complete residential and agricultural address across pages"
        cross_page_continuation: true
        required: true
      land_holdings:
        type: "array"
        description: "Table of land survey numbers, village, area in hectares, and crop"
        cross_page_continuation: true
        compact_tuple_encoding: true
        items:
          type: "object"
          properties:
            survey_number: { type: "string" }
            village: { type: "string" }
            area_hectares: { type: "number" }
            crop_type: { type: "string" }
      sanctioned_amount_inr:
        type: "number"
        description: "Total loan sanctioned amount in INR"
        required: true
```

---

## Step 5: Hot Reloading & Data Grid Cache Synchronization

1. **Automatic File Watcher**: When `file_watch_enabled: true` is set in `platform.yaml`, the `config-template-service` monitors `/etc/idp/config`.
2. **Cache Invalidation**: Upon modifying any tenant or template YAML file, the service automatically updates the Red Hat Data Grid Hot Rod L1 Near-Cache (`idp-tenant-config-cache` and `idp-schema-fsm-cache`) without requiring service restarts.
3. **Verification**: Check cache sync via the configuration service logs:
   ```bash
   docker compose logs -f config-template-service
   ```

---

## Step 6: Migrating to Phase 2 (Oracle Database 19c)

When moving from Phase 1 YAML files to Phase 2 enterprise Oracle 19c storage:
1. Execute the DDL migration script:
   ```sql
   -- Applied from db/migrations/V1__oracle_19c_phase2_schema.sql
   CREATE TABLE IDP_TENANT_CONFIGS (
       TENANT_ID VARCHAR2(64) PRIMARY KEY,
       CONFIG_JSON CLOB CHECK (CONFIG_JSON IS JSON),
       UPDATED_AT TIMESTAMP DEFAULT SYSTIMESTAMP
   );
   ```
2. Update `config/platform.yaml` to set `backend: "ORACLE_DB"`.
