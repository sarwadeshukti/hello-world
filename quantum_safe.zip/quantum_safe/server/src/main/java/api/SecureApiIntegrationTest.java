package api;

import api.model.AuthRequest;
import api.model.AuthResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ExtendWith(SpringExtension.class) // Ensures Spring context loads for JUnit 5
class SecureApiIntegrationTest {
    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    void testCompleteUserFlow() {
        // 1. Login
        AuthRequest authRequest = new AuthRequest();
        authRequest.setUsername("admin");
        authRequest.setPassword("password");

        ResponseEntity<AuthResponse> loginResponse = restTemplate.postForEntity(
                "/api/auth/login",
                authRequest,
                AuthResponse.class
        );

        assertTrue(loginResponse.getStatusCode().is2xxSuccessful());
        AuthResponse auth = loginResponse.getBody();
        assertNotNull(auth);

        // 2. Get Person Details
        HttpHeaders headers = new HttpHeaders();
        headers.set("Session-Id", auth.getSessionId());

        ResponseEntity<String> personResponse = restTemplate.exchange(
                "/api/person",
                HttpMethod.GET,
                new HttpEntity<>(headers),
                String.class
        );

        assertTrue(personResponse.getStatusCode().is2xxSuccessful());
        assertNotNull(personResponse.getBody());

        // 3. Get Branch (no auth needed)
        ResponseEntity<String> branchResponse = restTemplate.getForEntity(
                "/api/branch",
                String.class
        );

        assertTrue(branchResponse.getStatusCode().is2xxSuccessful());
        assertEquals("456 Branch St, City", branchResponse.getBody());
    }
}
