# Product Requirement Document & System Architecture (v4.0 — AI Implementation Spec)
## Project: Enterprise API-First Intelligent Document Processing (IDP) & Hybrid OCR Platform

---

## 1. Executive Summary & System Vision

Build a high-performance, cloud-native, multi-tenant, API-first Intelligent Document Processing (IDP) platform capable of ingesting, classifying, and extracting structured JSON data from single- and multi-page documents (`.jpg`, `.png`, `.pdf`, `.docx`) across English and major Indian languages (Hindi, Marathi, Tamil, Telugu, Bengali, Kannada, etc.).

### Core Architectural Tenets
1. **Tri-Track Hybrid Compute & Per-Page Routing:**
   - **Track A — Digital-Native Bypass (< 200ms):** Inspects PDF/DOCX object trees via `pdfium`. If native UTF-8 text layers exist without scanned raster images, bypasses image rasterization and vision inference entirely.
   - **Track B — CPU Fast-Track (< 2,000ms SLA, Target ~680ms):** Routes structured identity/financial documents (e.g., PAN card, Aadhaar card, standard forms) to INT8 quantized ONNX Runtime / OpenVINO OCR pipelines (PaddleOCR + Indic-OCR + LayoutLMv3 + Rust Regex/Fuzzy Matcher).
   - **Track C — Hyper-Parallel GPU Complex-Track (VLM):** Routes unstructured, handwritten, or dense documents to Vision Language Models (VLMs) served via **self-hosted vLLM** (with Automatic Prefix Caching, FP8 quantization, Guided JSON Decoding, and Speculative Decoding) or **Hugging Face Inference Endpoints** (`hftoken`).
2. **Hyper-Parallel Multi-Page VLM Map-Reduce with Conditional Seam Strips:**
   - All pages of a multi-page document are rasterized in parallel via a C++ `pdfium` SIMD thread pool into shared memory (`/dev/shm`).
   - A **Margin Ink Gatekeeper** checks if both the bottom 12% of Page $k$ and top 12% of Page $k+1$ contain active ink/tables. Only when a boundary is active does it synthesize a **Boundary Seam Strip** (bottom 15% of Page $k$ + top 15% of Page $k+1$).
   - All full pages and active seam strips fan out concurrently (`asyncio.gather` / gRPC streams) in a single vLLM super-batch.
   - A deterministic **Rust/C++ Reduce Merger** uses Seam Strip anchors and Red Hat Data Grid state to stitch split tables and multi-page strings in under 20ms.
3. **Decoupled Step-Wise Telemetry API (`GET /v1/telemetry/jobs/{job_id}`):**
   - Primary extraction responses (`POST /v1/documents/extract`) return clean business JSON only.
   - Nanosecond step timings are captured in a lock-free ring buffer and flushed asynchronously to **Red Hat Data Grid** and **Oracle Database 19c**, exposed via a dedicated Telemetry API.
4. **Red Hat Data Grid (Infinispan) State Backbone:**
   - Replaces Redis across all services using the Hot Rod protocol with Client-Side L1 Near-Caching (`InvalidatedNearCache`) and Write-Behind (`write-behind`) persistence.
5. **File-First Configuration (Phase 1) with Oracle Database 19c Migration Path (Phase 2):**
   - Tenant configs, storage routing rules, and Global/Tenant schema templates (`scope: GLOBAL | TENANT`) are stored in declarative YAML/JSON files in Phase 1 and cached in Red Hat Data Grid, abstracted behind a `ConfigurationRepository` interface for zero-code-change migration to **Oracle Database 19c (SecureFiles BLOB with `IS JSON` constraint)** in Phase 2.
6. **Pluggable Per-Tenant Storage SPI (Async Write-Behind Default):**
   - Supports **Red Hat OpenShift Data Foundation (ODF / Ceph S3)**, **MinIO S3**, **Oracle Database 19c (SecureFiles BLOB + `IS JSON` Checked Storage)**, and **Zero-Retention (`MEMORY_ONLY`)** per tenant.
7. **Dual-Target Container Deployment:**
   - Local development on **Docker Desktop (`docker-compose.yml`)** and production deployment on **Red Hat OpenShift Container Platform (OCP)** using UBI9 rootless images.

---

## 2. Recommended Monorepo Directory Structure (For AI Code Generation)

```text
idp-platform/
├── deploy/
│   ├── docker-compose.yml                 # Local Docker Desktop stack (Infinispan, Kafka, MinIO, Oracle 19c, Services)
│   └── openshift/                         # Helm charts / Kustomize manifests for Red Hat OpenShift (OCP)
├── config/                                # Phase 1 File-Based Configs (mounted at /etc/idp/config)
│   ├── platform.yaml
│   ├── tenants/
│   │   └── tnt_maharashtra_fin_01.yaml
│   └── templates/
│       ├── global/
│       │   ├── pan_card_v1.yaml
│       │   └── kyc_base_v1.yaml
│       └── tenants/
│           └── tnt_maharashtra_fin_01/
│               └── agri_loan_multipage_v1.yaml
├── proto/                                 # Internal gRPC Protobuf contracts
│   ├── ingestion.proto
│   ├── worker_inference.proto
│   └── telemetry.proto
├── services/
│   ├── api-gateway/                       # Envoy / FastAPI or Quarkus Edge Gateway + Rate Limiter
│   ├── config-template-service/           # File-based YAML loader + Red Hat Data Grid L1/L2 Cache + Oracle 19c DAO
│   ├── splitter-router-service/           # C++ pdfium bindings, Native Text Bypass, Seam Gatekeeper, Router
│   ├── cpu-ocr-worker/                    # ONNX Runtime / OpenVINO INT8, PaddleOCR, Indic-OCR, LayoutLMv3
│   ├── gpu-vlm-worker/                    # Async vLLM & HuggingFace (hftoken) client, Guided FSM, Tuple Decoder
│   ├── reduce-storage-service/            # Cross-page Stitcher, PII Redactor, Write-Behind Storage SPI
│   └── telemetry-service/                 # Lock-free Ring Buffer consumer + GET /v1/telemetry/jobs/{job_id}
└── db/
    └── migrations/
        └── V1__oracle_19c_phase2_schema.sql # Oracle 19c DDL (SecureFiles BLOB + IS JSON Constraints)
```

---

## 3. Component Architecture & Technical Specifications

### 3.1 API Gateway & Edge Layer
- **Protocols:** External REST/HTTP2 (`multipart/form-data` and `application/json`), internal gRPC over HTTP/2.
- **Security:** mTLS, OAuth2/OIDC JWT validation, and Tenant API Key authentication.
- **Rate Limiting:** Atomic token-bucket counters stored in **Red Hat Data Grid** (`rate-limit-counters`).
- **Headers Injected:** Generates a ULID `job_id`, initializes the monotonic `StepTelemetryCollector`, and returns `X-Job-ID` and `X-Telemetry-URI: /v1/telemetry/jobs/{job_id}` in the HTTP response headers.

### 3.2 Multi-Tenant Configuration & Hierarchical Template Service
- **Repository Pattern (`ConfigRepository`):**
  - `YamlFileConfigRepository` (Phase 1 Active): Reads `/etc/idp/config/tenants/*.yaml` and `/etc/idp/config/templates/**/*.yaml`. Uses `inotify` / `watchfiles` to hot-reload file changes into Red Hat Data Grid.
  - `Oracle19cConfigRepository` (Phase 2 Ready): Queries Oracle Database 19c tables `IDP_TENANT_CONFIGS` and `IDP_SCHEMA_TEMPLATES` using `JSON_SERIALIZE` and direct UTF-8 byte array (`getBytes`/`setBytes`) bindings on `IS JSON` SecureFiles BLOB columns. Enabled by setting `CONFIG_BACKEND=ORACLE_DB`.
- **Template Inheritance & Override Order:**
  1. `Global Template` (`scope: GLOBAL`, e.g., `global:kyc_base_v1`)
  2. `Tenant Template` (`scope: TENANT`, e.g., `tnt_maharashtra_fin_01:agri_loan_multipage_v1`, optionally extending a Global template)
  3. `Inline Request Schema Override` (`extraction_schema_override` passed in the multipart API call)
- **Pre-Compiled Schema FSM Cache:**
  - Compiles the resolved JSON Schema into an XGrammar / Outlines Finite State Machine (FSM) once and caches the binary automaton in Red Hat Data Grid keyed by `SHA256(resolved_schema_json)`.
- **Data Grid L1 Near-Cache:**
  - Hot Rod client configured with `NearCacheMode.INVALIDATED` so tenant configs and pre-compiled FSMs resolve in **0.1 ms** from local pod memory.

### 3.3 Pre-Processor, Per-Page Triage & Conditional Seam Builder
1. **DOCX & PDF Normalization:**
   - Converts `.docx` to PDF streams in memory or parses XML tables directly.
   - Uses multi-threaded `pdfium` to inspect each page of a PDF in parallel (`0.8 ms/page`).
2. **Per-Page Track Triage (`AUTO` mode or explicit override):**
   - **Track A (`DIGITAL_NATIVE_BYPASS`):** Triggered if page has embedded Unicode text streams and zero scanned image XObjects. Extracts text + bounding coordinates directly without pixel rasterization.
   - **Track B (`CPU_FAST`):** Triggered if `compute_tier == "CPU_FAST"` or if page triage detects clean printed text/standard form layout.
   - **Track C (`GPU_VLM`):** Triggered if `compute_tier == "GPU_VLM"` or if page triage detects handwriting, complex nested tables, or heavy skew.
3. **Conditional Boundary Seam Gatekeeper (For Multi-Page Documents):**
   - Evaluates the bottom 12% margin of Page $k$ and top 12% margin of Page $k+1$ using a horizontal pixel projection profile (`0.4 ms`).
   - **Rule:** Synthesize a `BoundarySeamStrip` (cropping bottom 15% of Page $k$ + top 15% of Page $k+1$ into a single composite image in `/dev/shm`) **ONLY IF** both adjacent margins contain active ink/table lines.
4. **Zero-Copy Shared Memory Arena (`/dev/shm`):**
   - Stores rasterized page buffers in POSIX shared memory segments (`/dev/shm/idp_{job_id}_p{n}`) and passes 64-byte memory descriptors over local gRPC or `nvJPEG` hardware decode pointers to GPU workers.

### 3.4 CPU Worker Pool (Fast-Track < 2s SLA)
- **Runtime:** ONNX Runtime / Intel OpenVINO with INT8 quantization and AVX-512/AMX instructions.
- **Models:**
  - Text Detection: Quantized DBNet++ (`INT8`).
  - Script Identification & Recognition: Quantized PaddleOCR (English/Latin) + Indic-OCR models (Devanagari for Hindi/Marathi, Tamil, Telugu, Kannada, Bengali).
  - Key-Value & Spatial Extraction: Quantized LayoutLMv3 (`INT8`) paired with a compiled Rust regex and RapidFuzz anchor matcher.

### 3.5 Hyper-Parallel GPU Worker Pool (Complex-Track VLM)
- **Supported VLM Providers:**
  1. **Self-Hosted vLLM Cluster (`provider: "vllm"`):**
     - Served with `--enable-prefix-caching`, `--quantization fp8`, and Speculative Decoding (`--speculative-model` / `--num-speculative-tokens 5`).
     - Uses Guided Decoding (`guided_json` / `guided_grammar`) backed by the pre-compiled schema FSM.
  2. **Hugging Face Inference Endpoints (`provider: "huggingface"`):**
     - Invokes remote or dedicated HF Endpoints over HTTPS using the `hftoken` provided in the multipart request `options.vlm_config.hftoken` or resolved from the tenant's encrypted secret configuration.
- **Prompt Compiler & Compact Positional Tuple Optimization:**
  - Combines: `[System Role] + [Schema Definition] + [Template/Request additional_prompt] + [Page Continuation Directives]`.
  - To cut output token generation latency by ~50%, array/table schemas are requested from the VLM as **compact positional arrays** (`[["104/2A", "Borgaon", 1.45, "Sugarcane"]]`) and expanded back into keyed JSON objects by the Rust Reduce Merger in `0.2 ms`.
- **Concurrent Map Fan-Out:**
  - Dispatches all $N$ pages and active Seam Strips concurrently in a single non-blocking batch (`asyncio.gather`).

### 3.6 Deterministic Cross-Page Reduce Merger, PII Redactor & Storage SPI
1. **Cross-Page Continuation & Table Stitching (< 20ms):**
   - Reads per-page outputs and Seam Strip outputs from Red Hat Data Grid (`page-mapreduce-cache`).
   - **String Continuations:** If Page $k$ flags a field with `_truncated_bottom: true` (or ends without terminal punctuation) and Seam $(k, k+1)$ or Page $k+1$ contains the continuation, concatenates the strings seamlessly and records `"source_pages": [k, k+1]`.
   - **Split Table Stitching:** Appends headerless continuation table rows from Page $k+1$ into the active array from Page $k$, using the Seam Strip output to deduplicate or repair any row split across the physical page cut.
2. **Mandatory PII Redaction Engine:**
   - Enforces field-level `mask_pii` policies (`"NONE" | "PARTIAL" | "REDACT"`).
   - Hard-coded compliance interceptor ensures forbidden sensitive national identifiers (such as Aadhaar numbers) are never logged or echoed in raw digits and are replaced with `[Aadhaar Redacted]` whenever redaction policy applies.
3. **Pluggable Per-Tenant Storage SPI with Write-Behind Offload:**
   - Enqueues the final payload into **Red Hat Data Grid** (`write-behind` cache) and immediately releases the HTTP response (`1.2 ms`).
   - Background storage workers persist the raw document and extracted JSON to the tenant's configured backend:
     - `REDHAT_ODF`: Ceph RGW S3 API (`s3://...`)
     - `MINIO_S3`: MinIO S3 API
     - `ORACLE_DB`: Oracle Database 19c SecureFiles `BLOB` for raw files + SecureFiles `BLOB` with `CHECK (EXTRACTED_JSON IS JSON)` constraint for extracted results
     - `MEMORY_ONLY`: Ephemeral RAM-only processing; zero disk persistence

---

## 4. Configuration File Schemas (Phase 1 YAML -> Phase 2 Oracle Database 19c)

### 4.1 Platform Configuration (`/etc/idp/config/platform.yaml`)
```yaml
apiVersion: idp.enterprise.in/v4
kind: PlatformConfiguration
spec:
  environment: "production" # "local-docker" | "openshift-prod"
  config_provider:
    backend: "FILE_YAML"    # "FILE_YAML" (Phase 1) | "ORACLE_DB" (Phase 2 - Oracle 19c)
    file_watch_enabled: true
    config_root_dir: "/etc/idp/config"
  datagrid:
    hotrod_servers: "datagrid-cluster.idp-infra.svc.cluster.local:11222"
    l1_nearcache_enabled: true
    l1_max_entries: 5000
    caches:
      tenant_config: "idp-tenant-config-cache"
      schema_fsm: "idp-schema-fsm-cache"
      ratelimit: "idp-ratelimit-counters"
      page_mapreduce: "idp-page-mapreduce-cache"
      telemetry: "idp-job-telemetry-cache"
      write_behind_storage: "idp-write-behind-storage-cache"
  kafka:
    bootstrap_servers: "amq-streams-kafka-bootstrap.idp-infra.svc.cluster.local:9092"
    topics:
      gpu_vlm_jobs: "idp.jobs.gpu.vlm"
      telemetry_events: "idp.telemetry.steps"
      storage_write_behind: "idp.storage.writebehind"
```

### 4.2 Tenant Configuration (`/etc/idp/config/tenants/tnt_maharashtra_fin_01.yaml`)
```yaml
apiVersion: idp.enterprise.in/v4
kind: TenantConfiguration
metadata:
  tenant_id: "tnt_maharashtra_fin_01"
  tenant_name: "Maharashtra Rural Finance Corp"
  status: "ACTIVE"
spec:
  rate_limits:
    requests_per_second: 250
    max_concurrent_vlm_pages: 64
  storage_policy:
    # Options: REDHAT_ODF | MINIO_S3 | ORACLE_DB | MEMORY_ONLY
    primary_backend: "REDHAT_ODF"
    write_mode: "ASYNC_WRITE_BEHIND" # "ASYNC_WRITE_BEHIND" | "STRICT_SYNC"
    retention_days: 90
    redhat_odf_config:
      endpoint: "[https://s3-openshift-storage.apps.ocp.enterprise.in](https://s3-openshift-storage.apps.ocp.enterprise.in)"
      bucket_name: "idp-tnt-mh-fin-01"
      region: "ap-south-1"
    minio_config:
      endpoint: "http://minio:9000"
      bucket_name: "local-idp-tnt-mh-fin-01"
    oracle_db_config:
      db_version: "19c"
      jdbc_url: "jdbc:oracle:thin:@//oracle19c-prod.enterprise.in:1521/IDPPDB1"
      lob_prefetch_size_bytes: 262144
      blob_table: "IDP_DOCUMENT_BLOBS"
      json_table: "IDP_EXTRACTION_RESULTS"
  compute_defaults:
    default_compute_tier: "AUTO"
    enable_digital_native_bypass: true
    enable_per_page_hybrid_routing: true
    enable_conditional_seam_strips: true
    vlm_config:
      default_provider: "vllm" # "vllm" | "huggingface"
      vllm_endpoint: "[http://vllm-qwen25-vl.idp-gpu.svc.cluster.local:8000](http://vllm-qwen25-vl.idp-gpu.svc.cluster.local:8000)"
      default_model_id: "Qwen/Qwen2.5-VL-7B-Instruct"
      enable_compact_tuple_tables: true
      huggingface_endpoint:
        url: "[https://xyz.us-east-1.aws.endpoints.huggingface.cloud](https://xyz.us-east-1.aws.endpoints.huggingface.cloud)"
        hftoken_env_var: "HF_TOKEN_TNT_MH_01"
  webhooks:
    on_completion_url: "[https://erp.mahafin.in/api/v1/idp/webhook](https://erp.mahafin.in/api/v1/idp/webhook)"
    hmac_secret_env_var: "WEBHOOK_SECRET_TNT_MH_01"
```

### 4.3 Global Template Definition (`/etc/idp/config/templates/global/kyc_base_v1.yaml`)
```yaml
apiVersion: idp.enterprise.in/v4
kind: ExtractionTemplate
metadata:
  template_id: "kyc_base_v1"
  scope: "GLOBAL"
  owner_tenant_id: null
spec:
  compute_tier: "CPU_FAST"
  languages: ["en", "hi", "mr", "ta"]
  additional_prompt: "Extract official Indian KYC fields accurately. Normalize all dates to YYYY-MM-DD."
  schema:
    fields:
      applicant_name:
        type: "string"
        description: "Full name of the individual"
        required: true
      pan_number:
        type: "string"
        description: "10-character alphanumeric PAN"
        regex: "^[A-Z]{5}[0-9]{4}[A-Z]{1}$"
        required: false
      government_uid:
        type: "string"
        description: "National identity number if present"
        mask_pii: "REDACT"
        required: false
      date_of_birth:
        type: "date"
        format: "YYYY-MM-DD"
        required: false
```

### 4.4 Tenant Template Extending Global Template (`/etc/idp/config/templates/tenants/tnt_maharashtra_fin_01/agri_loan_multipage_v1.yaml`)
```yaml
apiVersion: idp.enterprise.in/v4
kind: ExtractionTemplate
metadata:
  template_id: "agri_loan_multipage_v1"
  scope: "TENANT"
  owner_tenant_id: "tnt_maharashtra_fin_01"
  extends_template: "global:kyc_base_v1"
spec:
  compute_tier: "AUTO"
  languages: ["en", "mr", "hi"]
  multipage_config:
    enable_cross_page_continuation: true
    conditional_seam_gatekeeper: true
    seam_overlap_ratio: 0.15
  additional_prompt: >
    Multi-page Marathi and English agricultural loan form. Land survey tables
    (Gat / Survey numbers) frequently split across pages without repeating headers;
    merge all rows into `land_holdings`. Concatenate `property_address` if split across page breaks.
    Convert Devanagari numerals to standard Western Arabic numerals.
  schema:
    fields:
      property_address:
        type: "string"
        description: "Complete residential and agricultural address across pages"
        cross_page_continuation: true
        required: true
      land_holdings:
        type: "array"
        description: "Table of land survey numbers, village, area in hectares, and crop"
        cross_page_continuation: true
        compact_tuple_encoding: true
        items:
          type: "object"
          properties:
            survey_number: { type: "string" }
            village: { type: "string" }
            area_hectares: { type: "number" }
            crop_type: { type: "string" }
```

---

## 5. REST API Contracts & JSON Payload Specifications

### 5.1 Primary Document Extraction API (`POST /v1/documents/extract`)

#### Multipart Request Example
```http
POST /v1/documents/extract HTTP/1.1
Host: api.idp.enterprise.in
Authorization: Bearer <JWT_TOKEN>
X-Tenant-ID: tnt_maharashtra_fin_01
X-Idempotency-Key: 9f8e7d6c-5b4a-3f2e-1d0c-abcdef123456
Content-Type: multipart/form-data; boundary=---IDPBoundaryV4

-----IDPBoundaryV4
Content-Disposition: form-data; name="file"; filename="loan_application_3pages.pdf"
Content-Type: application/pdf

<BINARY_FILE_BYTES>
-----IDPBoundaryV4
Content-Disposition: form-data; name="options"
Content-Type: application/json

{
  "execution_mode": "SYNC",
  "compute_tier": "AUTO",
  "template_id": "tnt_maharashtra_fin_01:agri_loan_multipage_v1",
  "template_scope": "TENANT",
  "language_hints": ["en", "mr"],
  "additional_prompt": "Ignore 'DRAFT' watermarks. Preserve slash characters in survey_number.",
  "storage_override": {
    "backend": "REDHAT_ODF",
    "write_mode": "ASYNC_WRITE_BEHIND"
  },
  "vlm_config": {
    "provider": "vllm",
    "model_id": "Qwen/Qwen2.5-VL-7B-Instruct",
    "hf_endpoint_url": null,
    "hftoken": null
  }
}
-----IDPBoundaryV4
Content-Disposition: form-data; name="extraction_schema_override"
Content-Type: application/json

{
  "fields": {
    "sanctioned_amount_inr": {
      "type": "number",
      "description": "Sanctioned loan amount on final page",
      "required": false
    }
  }
}
-----IDPBoundaryV4--
```

#### Clean Business Response (`200 OK` — Zero Telemetry Clutter)
```http
HTTP/1.1 200 OK
Content-Type: application/json
X-Job-ID: job_01N8X9P2Q4R6S8T0V2W4Y6Z8A
X-Telemetry-URI: /v1/telemetry/jobs/job_01N8X9P2Q4R6S8T0V2W4Y6Z8A
```

```json
{
  "job_id": "job_01N8X9P2Q4R6S8T0V2W4Y6Z8A",
  "tenant_id": "tnt_maharashtra_fin_01",
  "status": "COMPLETED",
  "pages_processed": 3,
  "template_resolved": {
    "template_id": "tnt_maharashtra_fin_01:agri_loan_multipage_v1",
    "scope": "TENANT",
    "inherited_from": "global:kyc_base_v1"
  },
  "storage_reference": {
    "backend": "REDHAT_ODF",
    "write_mode": "ASYNC_WRITE_BEHIND",
    "object_uri": "s3://idp-tnt-mh-fin-01/2026/10/23/job_01N8X9P2Q4R6S8T0V2W4Y6Z8A.pdf"
  },
  "extracted_data": {
    "applicant_name": {
      "value": "SURESH DATTATRAY PATIL",
      "confidence": 0.995,
      "source_pages": [1]
    },
    "pan_number": {
      "value": "ABCDE1234F",
      "confidence": 0.999,
      "source_pages": [1],
      "validation_status": "PASSED_REGEX"
    },
    "government_uid": {
      "value": "[Aadhaar Redacted]",
      "confidence": 0.996,
      "source_pages": [1],
      "validation_status": "REDACTED_BY_POLICY"
    },
    "date_of_birth": {
      "value": "1985-07-19",
      "confidence": 0.991,
      "source_pages": [1]
    },
    "property_address": {
      "value": "House No. 42, Near Gram Panchayat Office, Post Borgaon, Taluka Walwa, District Sangli, Maharashtra - 415413",
      "confidence": 0.986,
      "source_pages": [1, 2],
      "cross_page_stitched": true
    },
    "land_holdings": {
      "confidence": 0.989,
      "source_pages": [1, 2, 3],
      "cross_page_stitched": true,
      "value": [
        { "survey_number": "104/2A", "village": "Borgaon", "area_hectares": 1.45, "crop_type": "Sugarcane", "_page": 1 },
        { "survey_number": "105/1B", "village": "Borgaon", "area_hectares": 0.85, "crop_type": "Soybean", "_page": 2 },
        { "survey_number": "108/4", "village": "Walwa", "area_hectares": 2.10, "crop_type": "Turmeric", "_page": 3 }
      ]
    },
    "sanctioned_amount_inr": {
      "value": 450000.0,
      "confidence": 0.993,
      "source_pages": [3]
    }
  },
  "links": {
    "self": "/v1/jobs/job_01N8X9P2Q4R6S8T0V2W4Y6Z8A",
    "telemetry": "/v1/telemetry/jobs/job_01N8X9P2Q4R6S8T0V2W4Y6Z8A"
  }
}
```

---

### 5.2 Dedicated Step-Wise Telemetry API (`GET /v1/telemetry/jobs/{job_id}`)

#### Request
```http
GET /v1/telemetry/jobs/job_01N8X9P2Q4R6S8T0V2W4Y6Z8A HTTP/1.1
Host: api.idp.enterprise.in
Authorization: Bearer <JWT_TOKEN>
X-Tenant-ID: tnt_maharashtra_fin_01
```

#### Response (`200 OK`)
```json
{
  "job_id": "job_01N8X9P2Q4R6S8T0V2W4Y6Z8A",
  "tenant_id": "tnt_maharashtra_fin_01",
  "architecture_version": "4.0",
  "routing_summary": {
    "total_pages": 3,
    "digital_native_bypass_pages": 0,
    "cpu_fast_track_pages": 1,
    "gpu_vlm_track_pages": 2,
    "seam_strips_evaluated": 2,
    "seam_strips_dispatched": 1,
    "seam_strips_skipped_clean_margin": 1
  },
  "overall_timing": {
    "request_received_at": "2026-10-23T05:45:12.100Z",
    "response_sent_at": "2026-10-23T05:45:13.118Z",
    "total_client_response_time_ms": 1018.4,
    "async_post_response_persistence_ms": 68.2,
    "sla_target_ms": 2000.0,
    "sla_met": true
  },
  "critical_path_steps": [
    {
      "step_order": 1,
      "step_name": "gateway_auth_and_l1_nearcache_lookup",
      "start_offset_ms": 0.0,
      "duration_ms": 1.8,
      "percentage_of_response_time": 0.18,
      "metadata": {
        "cache_provider": "RedHatDataGrid_L1_NearCache",
        "precompiled_fsm_cache_hit": true
      }
    },
    {
      "step_order": 2,
      "step_name": "parallel_pdf_triage_and_shm_prep",
      "start_offset_ms": 1.8,
      "duration_ms": 14.5,
      "percentage_of_response_time": 1.42,
      "metadata": {
        "ipc_mode": "POSIX_SHM_ZERO_COPY",
        "seam_1_2_active": true,
        "seam_2_3_skipped": true
      }
    },
    {
      "step_order": 3,
      "step_name": "hybrid_parallel_page_inference",
      "start_offset_ms": 16.3,
      "wall_clock_duration_ms": 982.0,
      "percentage_of_response_time": 96.43,
      "metadata": {
        "vllm_prefix_cache_hit": true,
        "speculative_decoding_enabled": true,
        "compact_tuple_token_savings_pct": 52.0,
        "parallel_streams": [
          { "stream_id": "page_1", "track": "CPU_OPENVINO_INT8", "inference_ms": 540.2 },
          { "stream_id": "page_2", "track": "GPU_VLM_FP8", "inference_ms": 982.0 },
          { "stream_id": "page_3", "track": "GPU_VLM_FP8", "inference_ms": 910.4 },
          { "stream_id": "seam_1_2", "track": "GPU_VLM_FP8", "inference_ms": 512.1 }
        ]
      }
    },
    {
      "step_order": 4,
      "step_name": "rust_reduce_stitch_and_pii_redaction",
      "start_offset_ms": 998.3,
      "duration_ms": 18.9,
      "percentage_of_response_time": 1.86,
      "metadata": {
        "split_fields_stitched": 1,
        "table_rows_merged": 3
      }
    },
    {
      "step_order": 5,
      "step_name": "datagrid_write_behind_enqueue",
      "start_offset_ms": 1017.2,
      "duration_ms": 1.2,
      "percentage_of_response_time": 0.12
    }
  ],
  "async_post_response_steps": [
    {
      "step_name": "tenant_storage_flush",
      "backend": "REDHAT_ODF",
      "duration_ms": 68.2,
      "status": "PERSISTED"
    }
  ]
}
```

---

## 6. Phase 2 Oracle Database 19c DDL Specification (`V1__oracle_19c_phase2_schema.sql`)

In Oracle Database 19c, JSON payloads are stored in **SecureFiles `BLOB`** columns with an explicit `CHECK (column_name IS JSON)` constraint and `CACHE` enabled for optimal buffer-pool performance without UTF-16 character conversion overhead:

```sql
-- 1. Tenant Configurations Table (Oracle 19c Phase 2 replacement for /etc/idp/config/tenants/*.yaml)
CREATE TABLE IDP_TENANT_CONFIGS (
    TENANT_ID          VARCHAR2(128) PRIMARY KEY,
    TENANT_NAME        VARCHAR2(256) NOT NULL,
    STATUS             VARCHAR2(32)  DEFAULT 'ACTIVE' NOT NULL,
    STORAGE_BACKEND    VARCHAR2(32)  NOT NULL, -- REDHAT_ODF, MINIO_S3, ORACLE_DB, MEMORY_ONLY
    CONFIG_JSON        BLOB          NOT NULL,
    UPDATED_AT         TIMESTAMP WITH TIME ZONE DEFAULT SYSTIMESTAMP NOT NULL,
    CONSTRAINT CK_TENANT_CFG_IS_JSON CHECK (CONFIG_JSON IS JSON)
) LOB (CONFIG_JSON) STORE AS SECUREFILE (CACHE);

-- 2. Hierarchical Schema Templates Table (GLOBAL and TENANT scopes in Oracle 19c)
CREATE TABLE IDP_SCHEMA_TEMPLATES (
    TEMPLATE_ID        VARCHAR2(128) NOT NULL,
    SCOPE              VARCHAR2(16)  NOT NULL CHECK (SCOPE IN ('GLOBAL', 'TENANT')),
    OWNER_TENANT_ID    VARCHAR2(128) DEFAULT 'GLOBAL' NOT NULL,
    EXTENDS_TEMPLATE   VARCHAR2(128),
    COMPUTE_TIER       VARCHAR2(32)  DEFAULT 'AUTO' NOT NULL,
    ADDITIONAL_PROMPT  CLOB,
    SCHEMA_JSON        BLOB          NOT NULL,
    COMPILED_FSM_BLOB  BLOB,
    UPDATED_AT         TIMESTAMP WITH TIME ZONE DEFAULT SYSTIMESTAMP NOT NULL,
    CONSTRAINT PK_IDP_TEMPLATES PRIMARY KEY (OWNER_TENANT_ID, TEMPLATE_ID),
    CONSTRAINT CK_TEMPLATE_SCHEMA_IS_JSON CHECK (SCHEMA_JSON IS JSON)
) LOB (SCHEMA_JSON) STORE AS SECUREFILE (CACHE)
  LOB (COMPILED_FSM_BLOB) STORE AS SECUREFILE (CACHE);

-- 3. Tenant Document Binary Storage (When Tenant selects primary_backend: ORACLE_DB)
CREATE TABLE IDP_DOCUMENT_BLOBS (
    JOB_ID             VARCHAR2(64)  PRIMARY KEY,
    TENANT_ID          VARCHAR2(128) NOT NULL,
    FILE_NAME          VARCHAR2(512),
    MIME_TYPE          VARCHAR2(128),
    DOCUMENT_BLOB      BLOB          NOT NULL,
    CREATED_AT         TIMESTAMP WITH TIME ZONE DEFAULT SYSTIMESTAMP NOT NULL
) LOB (DOCUMENT_BLOB) STORE AS SECUREFILE (COMPRESS HIGH DEDUPLICATE);

-- 4. Extracted Business Output Table (Oracle 19c SecureFiles BLOB with IS JSON)
CREATE TABLE IDP_EXTRACTION_RESULTS (
    JOB_ID             VARCHAR2(64)  PRIMARY KEY,
    TENANT_ID          VARCHAR2(128) NOT NULL,
    TEMPLATE_ID        VARCHAR2(128),
    STATUS             VARCHAR2(32)  NOT NULL,
    EXTRACTED_JSON     BLOB          NOT NULL,
    CREATED_AT         TIMESTAMP WITH TIME ZONE DEFAULT SYSTIMESTAMP NOT NULL,
    CONSTRAINT CK_EXTRACTED_RES_IS_JSON CHECK (EXTRACTED_JSON IS JSON)
) LOB (EXTRACTED_JSON) STORE AS SECUREFILE (CACHE);

-- 5. Decoupled Step-Wise Telemetry Table (Interval Partitioned by Day in Oracle 19c)
CREATE TABLE IDP_JOB_STEP_TELEMETRY (
    JOB_ID             VARCHAR2(64)  PRIMARY KEY,
    TENANT_ID          VARCHAR2(128) NOT NULL,
    COMPUTE_TIER_USED  VARCHAR2(32)  NOT NULL,
    TOTAL_PAGES        NUMBER(5)     NOT NULL,
    CLIENT_WALL_MS     NUMBER(10, 2) NOT NULL,
    SLA_MET            NUMBER(1)     NOT NULL,
    TELEMETRY_JSON     BLOB          NOT NULL,
    CREATED_AT         TIMESTAMP WITH TIME ZONE DEFAULT SYSTIMESTAMP NOT NULL,
    CONSTRAINT CK_TELEMETRY_IS_JSON CHECK (TELEMETRY_JSON IS JSON)
) LOB (TELEMETRY_JSON) STORE AS SECUREFILE (CACHE)
PARTITION BY RANGE (CREATED_AT) INTERVAL (NUMTODSINTERVAL(1, 'DAY')) (
    PARTITION P_INITIAL VALUES LESS THAN (TIMESTAMP '2026-01-01 00:00:00 +00:00')
);

-- Example Oracle 19c SQL/JSON Query for Serialization & Indexing
-- SELECT JSON_SERIALIZE(EXTRACTED_JSON RETURNING CLOB PRETTY) FROM IDP_EXTRACTION_RESULTS WHERE JOB_ID = :1;
```

---

## 7. Deployment Specifications

### 7.1 Local Development (`deploy/docker-compose.yml` for Docker Desktop)
- **Middleware Containers:**
  - `infinispan`: `quay.io/infinispan/server:15.0` (Red Hat Data Grid upstream compatible) exposing Hot Rod on `11222`.
  - `kafka`: `apache/kafka:3.8.0` (KRaft mode, zero ZooKeeper overhead) on `9092`.
  - `minio`: `quay.io/minio/minio:latest` on `9000` / `9001`.
  - `oracle-19c`: `container-registry.oracle.com/database/enterprise:19.3.0.0` (or pre-built Oracle 19c image) on `1521` for testing Oracle 19c SecureFiles `BLOB` + `IS JSON` constraints and Phase 2 config migration.
- **Application Services:** Mount `./config:/etc/idp/config:ro` and share a 2GB tmpfs volume at `/dev/shm` for zero-copy page tensor exchange.

### 7.2 Production (`deploy/openshift/` for Red Hat OpenShift Container Platform)
- **Base Images:** `registry.access.redhat.com/ubi9/ubi-minimal` running under OpenShift `restricted-v2` Security Context Constraints (non-root arbitrary UID).
- **Operators & Enterprise Backing Services:**
  - **Red Hat Data Grid Operator:** Multi-node Infinispan cluster with Hot Rod TLS and L1 Near-Cache invalidation.
  - **Red Hat AMQ Streams Operator:** Production Kafka cluster.
  - **Red Hat OpenShift Data Foundation (ODF):** Provides `ObjectBucketClaim` (Ceph RGW S3) for tenant storage and `ReadWriteMany` CephFS PVCs for shared ONNX/OpenVINO model weights.
  - **Oracle Database 19c Enterprise / RAC (with Active Data Guard):** Hosts Phase 2 configurations, templates, audit trails, and tenant-selected SecureFiles `BLOB` storage.
  - **Red Hat OpenShift AI (RHOAI) + NVIDIA GPU Operator + KEDA:** Hosts the multi-GPU `vLLM` serving pool with automatic horizontal pod scaling.

---

## 8. Non-Functional Requirements & SLA Matrix

| Metric / Capability | Target Specification |
| :--- | :--- |
| **1-Page Born-Digital PDF / DOCX Latency (P95)** | **< 200 ms** (via Digital-Native Bypass Track A) |
| **1-Page Scanned Structured ID Latency (P95)** | **< 850 ms** (Hard SLA: **< 2,000 ms** via CPU Fast-Track B) |
| **3-Page Mixed Unstructured Document (P95)** | **< 1,200 ms** (via Hyper-Parallel VLM + Conditional Seam Gatekeeper) |
| **10-Page Unstructured Contract (P95)** | **< 2,000 ms** (via vLLM Continuous Batching + Prefix Caching + Compact Tuples) |
| **Telemetry API Query Latency (`GET /v1/telemetry/jobs/{id}`)** | **< 5 ms P99** (served from Red Hat Data Grid `idp-job-telemetry-cache`) |
| **Multi-Tenant Isolation** | Per-tenant Data Grid rate limiters, isolated S3/ODF buckets or Oracle 19c schemas, and KMS key encryption |
| **PII & National ID Protection** | Mandatory in-memory redaction (`[Aadhaar Redacted]`) prior to logging, telemetry emission, or unmasked storage |