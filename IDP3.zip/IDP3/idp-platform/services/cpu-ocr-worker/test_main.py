import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_healthz():
    response = client.get("/healthz")
    assert response.status_code == 200
    assert response.json() == {"status": "healthy", "service": "cpu-ocr-worker"}

def test_process_cpu_ocr():
    payload = {
        "job_id": "job_12345",
        "page_number": 1,
        "shm_path": "/dev/shm/idp_page_p1.png",
        "languages": ["en", "mr"]
    }
    response = client.post("/v1/ocr/cpu-fast", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["job_id"] == "job_12345"
    assert data["page_number"] == 1
    assert data["track"] == "CPU_OPENVINO_INT8"
    assert data["status"] == "SUCCESS"
    assert "extracted_text" in data
