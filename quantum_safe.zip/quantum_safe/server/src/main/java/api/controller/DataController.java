package api.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import api.model.Person;
import api.service.CryptoService;
import api.service.SessionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class DataController {
    private final SessionService sessionService;
    private final CryptoService cryptoService;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    public DataController(SessionService sessionService, CryptoService cryptoService) {
        this.sessionService = sessionService;
        this.cryptoService = cryptoService;
    }

    @GetMapping("/person")
    public ResponseEntity<String> getPersonDetails(
            @RequestHeader("Session-Id") String sessionId) throws Exception {
        if (!sessionService.isValidSession(sessionId)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        Person person = new Person(
                "John Doe",
                "1990-01-01",
                "1234-5678-9012",
                "123 Main St, City"
        );

        String jsonPerson = objectMapper.writeValueAsString(person);
        String encryptionKey = sessionService.getEncryptionKey(sessionId);
        String encryptedData = cryptoService.encrypt(jsonPerson, encryptionKey);

        return ResponseEntity.ok(encryptedData);
    }

    @GetMapping("/branch")
    public ResponseEntity<String> getNearestBranch() {
        return ResponseEntity.ok("456 Branch St, City");
    }
}