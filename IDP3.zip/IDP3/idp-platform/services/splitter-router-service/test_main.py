import os
import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_healthz():
    response = client.get("/healthz")
    assert response.status_code == 200
    assert response.json() == {"status": "healthy", "service": "splitter-router-service"}

def test_split_and_route():
    sample_pdf_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../sample.pdf"))
    if os.path.exists(sample_pdf_path):
        with open(sample_pdf_path, "rb") as f:
            pdf_bytes = f.read()
    else:
        pdf_bytes = b"%PDF-1.4 dummy pdf bytes..."

    response = client.post(
        "/v1/split-route",
        files={"file": ("sample.pdf", pdf_bytes, "application/pdf")}
    )
    assert response.status_code == 200
    data = response.json()
    assert "total_pages" in data
    assert "routing_plan" in data
    assert "seam_gatekeeper" in data
