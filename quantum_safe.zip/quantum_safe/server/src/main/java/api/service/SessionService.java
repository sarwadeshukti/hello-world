package api.service;

import api.model.AuthResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.time.Instant;

@Service
public class SessionService {
    private final Map<String, SessionInfo> sessions = new ConcurrentHashMap<>();
    private final CryptoService cryptoService;

    // 30 minutes session timeout
    private static final long SESSION_TIMEOUT_MINUTES = 30;

    @Autowired
    public SessionService(CryptoService cryptoService) {
        this.cryptoService = cryptoService;
    }

    public AuthResponse createSession(String username) {
        String sessionId = java.util.UUID.randomUUID().toString();
        String encryptionKey = cryptoService.generateEncryptionKey();

        SessionInfo sessionInfo = new SessionInfo(
                username,
                encryptionKey,
                Instant.now()
        );

        sessions.put(sessionId, sessionInfo);

        System.out.println("Created session id: " + sessionId);
        return new AuthResponse(sessionId, encryptionKey);
    }

    public boolean isValidSession(String sessionId) {
        if (sessionId == null) {
            return false;
        }

        SessionInfo session = sessions.get(sessionId);
        if (session == null) {
            return false;
        }

        // Check if session has expired
        if (hasSessionExpired(session.getLastAccessed())) {
            sessions.remove(sessionId);
            return false;
        }

        // Update last accessed time
        session.updateLastAccessed();
        return true;
    }

    public String getEncryptionKey(String sessionId) {
        SessionInfo session = sessions.get(sessionId);
        return session != null ? session.getEncryptionKey() : null;
    }

    public String getUsernameFromSessionId(String sessionId) {
        SessionInfo session = sessions.get(sessionId);
        return session != null ? session.getUsername() : null;
    }

    private boolean hasSessionExpired(Instant lastAccessed) {
        return lastAccessed.plusSeconds(SESSION_TIMEOUT_MINUTES * 60)
                .isBefore(Instant.now());
    }

    // Clean up expired sessions every 5 minutes
    @Scheduled(fixedRate = 300000)
    public void cleanupExpiredSessions() {
        sessions.entrySet().removeIf(entry ->
                hasSessionExpired(entry.getValue().getLastAccessed()));
    }

    // Inner class to hold session information
    private static class SessionInfo {
        private final String username;
        private final String encryptionKey;
        private Instant lastAccessed;

        public SessionInfo(String username, String encryptionKey, Instant lastAccessed) {
            this.username = username;
            this.encryptionKey = encryptionKey;
            this.lastAccessed = lastAccessed;
        }

        public String getUsername() { return username; }
        public String getEncryptionKey() { return encryptionKey; }
        public Instant getLastAccessed() { return lastAccessed; }

        public void updateLastAccessed() {
            this.lastAccessed = Instant.now();
        }
    }
}