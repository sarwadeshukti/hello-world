/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function __wbg_secureclient_free(a: number, b: number): void;
export function secureclient_new(a: number, b: number, c: number, d: number, e: number): void;
export function secureclient_login(a: number, b: number, c: number, d: number): number;
export function secureclient_get_person_details(a: number): number;
export function secureclient_decrypt(a: number, b: number, c: number, d: number): void;
export function __wbindgen_malloc(a: number, b: number): number;
export function __wbindgen_realloc(a: number, b: number, c: number, d: number): number;
export const __wbindgen_export_2: WebAssembly.Table;
export function _dyn_core__ops__function__FnMut__A____Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__hd63007e167c1f1e8(a: number, b: number, c: number): void;
export function __wbindgen_add_to_stack_pointer(a: number): number;
export function __wbindgen_free(a: number, b: number, c: number): void;
export function __wbindgen_exn_store(a: number): void;
export function wasm_bindgen__convert__closures__invoke2_mut__h30bdda6885f6724c(a: number, b: number, c: number, d: number): void;
