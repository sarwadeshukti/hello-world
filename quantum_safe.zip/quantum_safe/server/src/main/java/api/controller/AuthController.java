package api.controller;

import api.model.AuthRequest;
import api.model.AuthResponse;
import api.service.SessionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final SessionService sessionService;

    @Autowired
    public AuthController(SessionService sessionService) {
        this.sessionService = sessionService;
    }

    @PostMapping("/login")
    @CrossOrigin(origins = "http://localhost:8000", allowCredentials = "true")
    public ResponseEntity<AuthResponse> login(@RequestBody AuthRequest request) {
        System.out.println("Reached AuthController login endpoint");
        if ("admin".equals(request.getUsername()) &&
                "password".equals(request.getPassword())) {
            AuthResponse authResponse = sessionService.createSession(request.getUsername());
            System.out.println("Login successful. Session ID: " + authResponse.toString());
            return ResponseEntity.ok(authResponse);
        }
        System.out.println("Login failed for user: " + request.getUsername());
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }
}
