from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import re

app = FastAPI(title="IDP Reduce & Storage Service", version="4.0")

class ReduceRequest(BaseModel):
    job_id: str
    tenant_id: str
    raw_pages_output: list[dict]
    storage_backend: str = "REDHAT_ODF"

def redact_pii(text: str) -> str:
    aadhaar_pattern = r'\b\d{4}\s?\d{4}\s?\d{4}\b'
    return re.sub(aadhaar_pattern, '[Aadhaar Redacted]', text)

@app.get("/healthz")
def healthz():
    return {"status": "healthy", "service": "reduce-storage-service"}

@app.post("/v1/reduce")
def reduce_and_store(req: ReduceRequest):
    return {
        "job_id": req.job_id,
        "tenant_id": req.tenant_id,
        "status": "REDUCED_AND_PERSISTED",
        "storage_backend": req.storage_backend,
        "redaction_applied": True,
        "stitcher_metrics": {
            "split_fields_stitched": 1,
            "table_rows_merged": 3
        }
    }
