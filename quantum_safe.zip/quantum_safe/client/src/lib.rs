// File: src/lib.rs
use wasm_bindgen::prelude::*;
use aes_gcm::{
    aead::{Aead, KeyInit},
    Aes256Gcm,
    Nonce,
};
use base64::{Engine as _, engine::general_purpose::STANDARD as BASE64};
use web_sys::console;

mod models;
use models::{Person, LoginResponse};

#[wasm_bindgen]
pub struct SecureClient {
    session_id: String,
    encryption_key: Vec<u8>,
}

#[wasm_bindgen]
impl SecureClient {
    #[wasm_bindgen(constructor)]
    pub fn new(session_id: &str, base64_key: &str) -> Result<SecureClient, JsValue> {
        console_error_panic_hook::set_once();

        let encryption_key = BASE64.decode(base64_key)
            .map_err(|e| JsValue::from_str(&format!("Invalid key: {}", e)))?;

        // Validate key size (32 bytes for AES-256)
        if encryption_key.len() != 32 {
            return Err(JsValue::from_str("Invalid key size. Expected 32 bytes."));
        }

        Ok(SecureClient {
            session_id: session_id.to_string(),
            encryption_key,
        })
    }

    #[wasm_bindgen]
    pub async fn login(username: &str, password: &str) -> Result<JsValue, JsValue> {
        let window = web_sys::window().ok_or("No window found")?;

        // Create request init object
        let mut opts = web_sys::RequestInit::new();
        opts.method("POST");
        opts.mode(web_sys::RequestMode::Cors);

        // Create request body
        let body = format!(
            r#"{{"username":"{}","password":"{}"}}"#,
            username, password
        );
        opts.body(Some(&JsValue::from_str(&body)));

        // Set headers
        let headers = js_sys::Object::new();
        js_sys::Reflect::set(
            &headers,
            &JsValue::from_str("Content-Type"),
            &JsValue::from_str("application/json"),
        )?;
        opts.headers(&headers);

        // Create and send request
        let request = web_sys::Request::new_with_str_and_init(
            "https://localhost:8443/api/auth/login",
            &opts,
        )?;

        let resp_value = wasm_bindgen_futures::JsFuture::from(
            window.fetch_with_request(&request)
        ).await?;

        let resp: web_sys::Response = resp_value.dyn_into()?;

        if !resp.ok() {
            return Err(JsValue::from_str(&format!(
                "HTTP error! status: {}",
                resp.status()
            )));
        }

        let json = wasm_bindgen_futures::JsFuture::from(resp.json()?).await?;
        Ok(json)
    }

    // In your get_person_details function
    pub async fn get_person_details(&self) -> Result<JsValue, JsValue> {
        console::log_1(&"Starting get_person_details request...".into());

        let window = web_sys::window().ok_or("No window found")?;

        let mut opts = web_sys::RequestInit::new();
        opts.set_method("GET");
        opts.set_mode(web_sys::RequestMode::Cors);

        // Set headers
        let headers = js_sys::Object::new();
        js_sys::Reflect::set(
            &headers,
            &JsValue::from_str("Session-Id"),
            &JsValue::from_str(&self.session_id),
        )?;
        opts.set_headers(&headers);

        console::log_1(&format!("Sending request with session ID: {}", self.session_id).into());

        let request = web_sys::Request::new_with_str_and_init(
            "http://localhost:8443/api/person",
            &opts,
        )?;

        let resp_value = wasm_bindgen_futures::JsFuture::from(
            window.fetch_with_request(&request)
        ).await?;

        let resp: web_sys::Response = resp_value.dyn_into()?;

        if !resp.ok() {
            let status = resp.status();
            let text = wasm_bindgen_futures::JsFuture::from(resp.text()?).await?;
            console::log_1(&format!("Error response: Status {}, Body: {}",
                                    status,
                                    text.as_string().unwrap_or_default()
            ).into());
            return Err(JsValue::from_str(&format!(
                "HTTP error! status: {}, body: {}",
                status,
                text.as_string().unwrap_or_default()
            )));
        }

        console::log_1(&"Received response, getting text...".into());
        let encrypted_text = wasm_bindgen_futures::JsFuture::from(resp.text()?).await?;

        console::log_1(&"Attempting to decrypt response...".into());
        let decrypted = self.decrypt(encrypted_text.as_string().unwrap())?;

        console::log_1(&format!("Decrypted data: {}", decrypted).into());
        Ok(JsValue::from_str(&decrypted))
    }

    // Similarly update your login function
    pub async fn login(username: &str, password: &str) -> Result<JsValue, JsValue> {
        let window = web_sys::window().ok_or("No window found")?;

        let mut opts = web_sys::RequestInit::new();
        opts.set_method("POST");
        opts.set_mode(web_sys::RequestMode::Cors);

        // Create request body
        let body = format!(
            r#"{{"username":"{}","password":"{}"}}"#,
            username, password
        );
        opts.set_body(Some(&JsValue::from_str(&body)));

        // Set headers
        let headers = js_sys::Object::new();
        js_sys::Reflect::set(
            &headers,
            &JsValue::from_str("Content-Type"),
            &JsValue::from_str("application/json"),
        )?;
        opts.set_headers(&headers);

        let request = web_sys::Request::new_with_str_and_init(
            "http://localhost:8443/api/auth/login",
            &opts,
        )?;

        let resp_value = wasm_bindgen_futures::JsFuture::from(
            window.fetch_with_request(&request)
        ).await?;

        let resp: web_sys::Response = resp_value.dyn_into()?;

        if !resp.ok() {
            let status = resp.status();
            let text = wasm_bindgen_futures::JsFuture::from(resp.text()?).await?;
            return Err(JsValue::from_str(&format!(
                "HTTP error! status: {}, body: {}",
                status,
                text.as_string().unwrap_or_default()
            )));
        }

        let json = wasm_bindgen_futures::JsFuture::from(resp.json()?).await?;
        Ok(json)
    }
    pub fn decrypt(&self, encrypted_base64: String) -> Result<String, JsValue> {
        console::log_1(&"Starting decryption".into());

        // Decode base64
        let encrypted_data = BASE64.decode(&encrypted_base64)
            .map_err(|e| JsValue::from_str(&format!("Base64 decode error: {}", e)))?;

        // Split nonce (12 bytes) and ciphertext
        if encrypted_data.len() < 12 {
            return Err(JsValue::from_str("Invalid encrypted data format"));
        }

        let (nonce_bytes, ciphertext) = encrypted_data.split_at(12);

        // Create cipher instance
        let cipher = Aes256Gcm::new_from_slice(&self.encryption_key)
            .map_err(|e| JsValue::from_str(&format!("Cipher error: {}", e)))?;

        let nonce = Nonce::from_slice(nonce_bytes);

        // Decrypt
        let plaintext = cipher.decrypt(nonce, ciphertext)
            .map_err(|e| JsValue::from_str(&format!("Decryption error: {}", e)))?;

        String::from_utf8(plaintext)
            .map_err(|e| JsValue::from_str(&format!("UTF-8 decode error: {}", e)))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use wasm_bindgen_test::*;

    #[wasm_bindgen_test]
    fn test_client_creation() {
        // Generate a valid 32-byte key
        let valid_key = [0u8; 32];
        let base64_key = BASE64.encode(valid_key);

        let client = SecureClient::new(
            "test-session",
            &base64_key
        ).unwrap();
        assert_eq!(client.session_id, "test-session");
        assert_eq!(client.encryption_key.len(), 32);
    }

    #[wasm_bindgen_test]
    fn test_invalid_key_size() {
        // Try with invalid key size
        let invalid_key = [0u8; 16];
        let base64_key = BASE64.encode(invalid_key);

        let result = SecureClient::new("test-session", &base64_key);
        assert!(result.is_err());
    }
}