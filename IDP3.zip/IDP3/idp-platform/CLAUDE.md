# CLAUDE.md — Enterprise API-First IDP & Hybrid OCR Platform (v4.0)

This file provides guidance to Claude Code (claude.ai/code) and developers working in this repository.

---

## 1. Quick Start & Common Commands

### Local Infrastructure & Services (Docker Compose)
- **Start Docker Stack**: `cd idp-platform/deploy && docker compose up --build -d`
- **Stop Docker Stack**: `cd idp-platform/deploy && docker compose down`
- **View Container Logs**: `cd idp-platform/deploy && docker compose logs -f [service_name]`

### Testing & Validation
- **Run Unit Tests (Pytest across services)**:
  ```bash
  pytest
  ```
- **Test Extraction API (Multi-page Agri Loan / KYC)**:
  ```bash
  curl -X POST http://localhost:8080/v1/documents/extract \
    -H "X-Tenant-ID: tnt_maharashtra_fin_01" \
    -F "file=@idp-platform/test-data/sample.pdf" \
    -F 'options={"template_id": "agri_loan_multipage_v1"}'
  ```
- **Test Extraction API (Aadhaar Card / ID)**:
  ```bash
  curl -X POST http://localhost:8080/v1/documents/extract \
    -H "X-Tenant-ID: tnt_maharashtra_fin_01" \
    -F "file=@idp-platform/test-data/aadhar-3.png" \
    -F 'options={"template_id": "aadhar_card_v1"}'
  ```
- **Test Telemetry API**:
  ```bash
  curl http://localhost:8080/v1/telemetry/jobs/{job_id} \
    -H "X-Tenant-ID: tnt_maharashtra_fin_01"
  ```

---

## 2. Architecture & High-Level Design (PRD v4.0)

### 2.1 Tri-Track Hybrid Compute Architecture
1. **Track A — Digital-Native Bypass (< 200ms)**: Inspects PDF/DOCX object trees via `pdfium`. Bypasses image rasterization and vision inference entirely when native UTF-8 text layers exist.
2. **Track B — CPU Fast-Track (< 2,000ms SLA, Target ~680ms)**: INT8 quantized ONNX Runtime / OpenVINO OCR pipelines (PaddleOCR + Indic-OCR + LayoutLMv3 + Rust Regex/Fuzzy Matcher) for structured identity and financial documents (e.g. PAN, Aadhaar).
3. **Track C — Hyper-Parallel GPU Complex-Track (VLM)**: Routes unstructured, handwritten, or dense multi-page documents to Vision Language Models (VLMs) served via self-hosted vLLM (with Automatic Prefix Caching, FP8 quantization, Guided JSON Decoding / FSM, and Speculative Decoding) or Hugging Face Inference Endpoints.

### 2.2 Multi-Page Conditional Seam Strips & Reduce Merger
- **Margin Ink Gatekeeper**: Evaluates bottom 12% margin of Page $k$ and top 12% margin of Page $k+1$. Synthesizes a Boundary Seam Strip (bottom 15% of Page $k$ + top 15% of Page $k+1$) **only when both margins contain active ink/tables**.
- **Reduce Merger**: Rust/C++ deterministic cross-page stitcher that merges split table rows and multi-page string continuations in under 20ms using Seam Strip anchors.

### 2.3 State & Configuration Backbone
- **Phase 1 (Active)**: File-based YAML configs located in `idp-platform/config/` (`config/platform.yaml`, `config/tenants/`, `config/templates/`). Hot-loaded into Red Hat Data Grid (Infinispan) with L1 Near-Cache (`InvalidatedNearCache`).
- **Phase 2 (Ready)**: Oracle Database 19c SecureFiles `BLOB` with `CHECK (EXTRACTED_JSON IS JSON)` constraints (`idp-platform/db/migrations/V1__oracle_19c_phase2_schema.sql`).
- **Messaging**: Apache Kafka (KRaft mode) for asynchronous job dispatch, telemetry events, and storage write-behind offload.

### 2.4 Pluggable Per-Tenant Storage SPI
- Supports **Red Hat OpenShift Data Foundation (ODF / Ceph S3)**, **MinIO S3**, **Oracle Database 19c (SecureFiles BLOB + IS JSON)**, and **Zero-Retention (`MEMORY_ONLY`)** per tenant with async write-behind default.
- **Mandatory PII Redaction**: Field-level `mask_pii` policies (`REDACT`) ensure sensitive identifiers (such as Aadhaar numbers) are masked in memory prior to logging, telemetry, or storage.

---

## 3. Monorepo Directory Structure

```text
idp-platform/
├── deploy/
│   ├── docker-compose.yml                 # Local Docker stack (Infinispan, Kafka, MinIO, Oracle 19c, Services)
│   └── openshift/                         # OpenShift Helm charts / manifests (UBI9 rootless images)
├── config/                                # Phase 1 File-Based Configs
│   ├── platform.yaml
│   ├── tenants/
│   │   └── tnt_maharashtra_fin_01.yaml
│   └── templates/
│       ├── global/
│       │   ├── kyc_base_v1.yaml
│       │   └── aadhar_card_v1.yaml
│       └── tenants/
│           └── tnt_maharashtra_fin_01/
│               └── agri_loan_multipage_v1.yaml
├── proto/                                 # Internal gRPC Protobuf contracts
│   ├── ingestion.proto
│   ├── worker_inference.proto
│   └── telemetry.proto
├── services/
│   ├── api-gateway/                       # FastAPI Edge Gateway & Orchestrator
│   ├── config-template-service/           # YAML / Oracle 19c Config Loader & Data Grid L1 Cache DAO
│   ├── splitter-router-service/           # C++ pdfium bindings, Native Text Bypass, Seam Gatekeeper, Router
│   ├── cpu-ocr-worker/                    # ONNX Runtime / OpenVINO INT8, PaddleOCR, Indic-OCR, LayoutLMv3
│   ├── gpu-vlm-worker/                    # Async vLLM & Hugging Face client, Guided FSM, Tuple Decoder
│   ├── reduce-storage-service/            # Cross-page Stitcher, PII Redactor, Write-Behind Storage SPI
│   └── telemetry-service/                 # Lock-free Ring Buffer consumer & GET /v1/telemetry/jobs/{job_id}
└── db/
    └── migrations/
        └── V1__oracle_19c_phase2_schema.sql # Oracle 19c DDL (SecureFiles BLOB + IS JSON Constraints)
```
