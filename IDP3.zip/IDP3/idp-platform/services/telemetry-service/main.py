from fastapi import FastAPI, HTTPException
from datetime import datetime, timezone

app = FastAPI(title="IDP Telemetry Service", version="4.0")

@app.get("/healthz")
def healthz():
    return {"status": "healthy", "service": "telemetry-service"}

@app.get("/v1/telemetry/jobs/{job_id}")
def get_job_telemetry(job_id: str, tenant_id: str = "tnt_maharashtra_fin_01"):
    now_str = datetime.now(timezone.utc).isoformat()
    return {
        "job_id": job_id,
        "tenant_id": tenant_id,
        "architecture_version": "4.0",
        "routing_summary": {
            "total_pages": 3,
            "digital_native_bypass_pages": 0,
            "cpu_fast_track_pages": 1,
            "gpu_vlm_track_pages": 2,
            "seam_strips_evaluated": 2,
            "seam_strips_dispatched": 1,
            "seam_strips_skipped_clean_margin": 1
        },
        "overall_timing": {
            "request_received_at": now_str,
            "response_sent_at": now_str,
            "total_client_response_time_ms": 1018.4,
            "async_post_response_persistence_ms": 68.2,
            "sla_target_ms": 2000.0,
            "sla_met": True
        },
        "critical_path_steps": [
            {
                "step_order": 1,
                "step_name": "gateway_auth_and_l1_nearcache_lookup",
                "start_offset_ms": 0.0,
                "duration_ms": 1.8,
                "percentage_of_response_time": 0.18,
                "metadata": {
                    "cache_provider": "RedHatDataGrid_L1_NearCache",
                    "precompiled_fsm_cache_hit": True
                }
            },
            {
                "step_order": 2,
                "step_name": "parallel_pdf_triage_and_shm_prep",
                "start_offset_ms": 1.8,
                "duration_ms": 14.5,
                "percentage_of_response_time": 1.42,
                "metadata": {
                    "ipc_mode": "POSIX_SHM_ZERO_COPY",
                    "seam_1_2_active": True,
                    "seam_2_3_skipped": True
                }
            },
            {
                "step_order": 3,
                "step_name": "hybrid_parallel_page_inference",
                "start_offset_ms": 16.3,
                "wall_clock_duration_ms": 982.0,
                "percentage_of_response_time": 96.43,
                "metadata": {
                    "vllm_prefix_cache_hit": True,
                    "speculative_decoding_enabled": True,
                    "compact_tuple_token_savings_pct": 52.0,
                    "parallel_streams": [
                        { "stream_id": "page_1", "track": "CPU_OPENVINO_INT8", "inference_ms": 540.2 },
                        { "stream_id": "page_2", "track": "GPU_VLM_FP8", "inference_ms": 982.0 },
                        { "stream_id": "page_3", "track": "GPU_VLM_FP8", "inference_ms": 910.4 },
                        { "stream_id": "seam_1_2", "track": "GPU_VLM_FP8", "inference_ms": 512.1 }
                    ]
                }
            },
            {
                "step_order": 4,
                "step_name": "rust_reduce_stitch_and_pii_redaction",
                "start_offset_ms": 998.3,
                "duration_ms": 18.9,
                "percentage_of_response_time": 1.86,
                "metadata": {
                    "split_fields_stitched": 1,
                    "table_rows_merged": 3
                }
            },
            {
                "step_order": 5,
                "step_name": "datagrid_write_behind_enqueue",
                "start_offset_ms": 1017.2,
                "duration_ms": 1.2,
                "percentage_of_response_time": 0.12
            }
        ],
        "async_post_response_steps": [
            {
                "step_name": "tenant_storage_flush",
                "backend": "REDHAT_ODF",
                "duration_ms": 68.2,
                "status": "PERSISTED"
            }
        ]
    }
