import pytest
from fastapi.testclient import TestClient
from main import app, redact_pii

client = TestClient(app)

def test_healthz():
    response = client.get("/healthz")
    assert response.status_code == 200
    assert response.json() == {"status": "healthy", "service": "reduce-storage-service"}

def test_redact_pii():
    text = "My Aadhaar number is 1234 5678 9012 and PAN is ABCDE1234F."
    redacted = redact_pii(text)
    assert "[Aadhaar Redacted]" in redacted
    assert "1234 5678 9012" not in redacted

def test_reduce_and_store():
    payload = {
        "job_id": "job_12345",
        "tenant_id": "tnt_maharashtra_fin_01",
        "raw_pages_output": [
            {"page_number": 1, "text": "Page 1 content"}
        ],
        "storage_backend": "REDHAT_ODF"
    }
    response = client.post("/v1/reduce", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["job_id"] == "job_12345"
    assert data["tenant_id"] == "tnt_maharashtra_fin_01"
    assert data["status"] == "REDUCED_AND_PERSISTED"
    assert data["redaction_applied"] is True
