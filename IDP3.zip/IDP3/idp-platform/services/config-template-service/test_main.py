import os
import pytest
from fastapi.testclient import TestClient

os.environ["CONFIG_ROOT_DIR"] = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../config"))

from main import app

client = TestClient(app)

def test_healthz():
    response = client.get("/healthz")
    assert response.status_code == 200
    assert response.json() == {"status": "healthy", "service": "config-template-service"}

def test_get_tenant_config():
    response = client.get("/v1/config/tenants/tnt_maharashtra_fin_01")
    assert response.status_code == 200
    data = response.json()
    assert data["metadata"]["tenant_id"] == "tnt_maharashtra_fin_01"

def test_get_tenant_config_not_found():
    response = client.get("/v1/config/tenants/nonexistent_tenant")
    assert response.status_code == 404

def test_get_global_template():
    response = client.get("/v1/templates/GLOBAL/kyc_base_v1")
    assert response.status_code == 200
    data = response.json()
    assert "metadata" in data

def test_get_pan_card_global_template():
    response = client.get("/v1/templates/GLOBAL/pan_card_v1")
    assert response.status_code == 200
    data = response.json()
    assert data["metadata"]["template_id"] == "pan_card_v1"
    assert data["metadata"]["scope"] == "GLOBAL"
    assert "name" in data["spec"]["schema"]["fields"]
    assert "father_name" in data["spec"]["schema"]["fields"]
    assert "dob" in data["spec"]["schema"]["fields"]
    assert "pan" in data["spec"]["schema"]["fields"]

def test_get_tenant_template():
    response = client.get("/v1/templates/TENANT/agri_loan_multipage_v1?tenant_id=tnt_maharashtra_fin_01")
    assert response.status_code == 200
    data = response.json()
    assert "metadata" in data

def test_get_template_invalid_scope():
    response = client.get("/v1/templates/INVALID/kyc_base_v1")
    assert response.status_code == 400
