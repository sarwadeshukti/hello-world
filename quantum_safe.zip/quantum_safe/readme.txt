# Project Root Directory Structure
secure-app/
├── README.md
├── server/              # Spring Boot server
└── client/              # Rust WASM client