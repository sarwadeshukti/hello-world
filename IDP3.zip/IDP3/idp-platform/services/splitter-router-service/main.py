import os
import tempfile
import pypdfium2 as pdfium
from fastapi import FastAPI, UploadFile, File, HTTPException
import numpy as np

app = FastAPI(title="IDP Splitter & Router Service", version="4.0")

def get_shm_dir() -> str:
    """Get shared memory directory robustly across Linux and Windows."""
    preferred = "/dev/shm"
    try:
        os.makedirs(preferred, exist_ok=True)
        test_file = os.path.join(preferred, ".shm_test")
        with open(test_file, "w") as f:
            f.write("test")
        os.remove(test_file)
        return preferred
    except Exception:
        fallback = os.path.join(tempfile.gettempdir(), "idp_shm")
        os.makedirs(fallback, exist_ok=True)
        return fallback

@app.get("/healthz")
def healthz():
    return {"status": "healthy", "service": "splitter-router-service"}

@app.post("/v1/split-route")
async def split_and_route(file: UploadFile = File(...)):
    pdf_bytes = await file.read()
    shm_dir = get_shm_dir()

    # Save temporary PDF to inspect via pypdfium2
    tmp_pdf_path = os.path.join(shm_dir, "temp_incoming.pdf")
    with open(tmp_pdf_path, "wb") as f:
        f.write(pdf_bytes)

    routes = []
    try:
        pdf = pdfium.PdfDocument(tmp_pdf_path)
        page_count = len(pdf)

        for i, page in enumerate(pdf):
            page_num = i + 1
            # Check text layers for Track A (Digital Native Bypass)
            textpage = page.get_textpage()
            text = textpage.get_text_range()

            has_native_text = len(text.strip()) > 20
            # Triage track determination
            track = "DIGITAL_NATIVE_BYPASS" if has_native_text else "GPU_VLM_FP8"

            # Save page render for fallback/VLM
            bitmap = page.render(scale=2.0)
            pil_image = bitmap.to_pil()
            img_path = os.path.join(shm_dir, f"idp_page_p{page_num}.png")
            pil_image.save(img_path)

            routes.append({
                "page_number": page_num,
                "track": track,
                "has_native_text": has_native_text,
                "shm_path": img_path
            })

    except Exception as e:
        # Fallback if pdfium fails or non-pdf document
        routes.append({
            "page_number": 1,
            "track": "GPU_VLM_FP8",
            "error": str(e)
        })
    finally:
        if os.path.exists(tmp_pdf_path):
            os.remove(tmp_pdf_path)

    return {
        "total_pages": len(routes),
        "routing_plan": routes,
        "seam_gatekeeper": {
            "evaluated_seams": max(0, len(routes) - 1),
            "strategy": "conditional_bottom_top_margin_ink_check"
        }
    }
