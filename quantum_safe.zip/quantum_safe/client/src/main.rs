mod models;

fn main() {
    println!("Hello, world!");
}
