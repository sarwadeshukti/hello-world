package api.service;

import api.model.AuthResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class SessionServiceTest {
    @Mock
    private CryptoService cryptoService;

    private SessionService sessionService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        when(cryptoService.generateEncryptionKey()).thenReturn("test-key");
        sessionService = new SessionService(cryptoService);
    }

    @Test
    void testCreateSession() {
        // When
        AuthResponse response = sessionService.createSession("testUser");

        // Then
        assertNotNull(response);
        assertNotNull(response.getSessionId());
        assertEquals("test-key", response.getEncryptionKey());
        assertTrue(sessionService.isValidSession(response.getSessionId()));
    }

    @Test
    void testIsValidSession() {
        // Given
        AuthResponse response = sessionService.createSession("testUser");

        // When/Then
        assertTrue(sessionService.isValidSession(response.getSessionId()));
        assertFalse(sessionService.isValidSession("invalid-session"));
    }

    @Test
    void testGetEncryptionKey() {
        // Given
        AuthResponse response = sessionService.createSession("testUser");

        // When
        String key = sessionService.getEncryptionKey(response.getSessionId());

        // Then
        assertEquals("test-key", key);
        assertNull(sessionService.getEncryptionKey("invalid-session"));
    }
}
