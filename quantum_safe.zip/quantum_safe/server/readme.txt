# Secure Server Application

Spring Boot server with AES-256-GCM encryption and session management.

## Setup Instructions

1. Prerequisites:
   - Java 17 or later
   - Maven
   - IntelliJ IDEA (recommended)

2. Import Project:
   - Open IntelliJ IDEA
   - File -> Open -> Navigate to server directory
   - Wait for Maven to download dependencies

3. Configuration:
   - Application properties in `src/main/resources/application.properties`
   - Security configuration in `SecurityConfig.java`
   - Encryption service in `CryptoService.java`

4. Build and Run:
```bash
mvn clean package
mvn spring-boot:run
```

## Project Structure
```
src/
├── main/
│   ├── java/
│   │   └── api/
│   │       ├── config/
│   │       │   ├── SecurityConfig.java
│   │       │   └── SessionAuthenticationFilter.java
│   │       ├── controller/
│   │       │   ├── AuthController.java
│   │       │   └── DataController.java
│   │       ├── model/
│   │       │   ├── AuthRequest.java
│   │       │   ├── AuthResponse.java
│   │       │   └── Person.java
│   │       └── service/
│   │           ├── CryptoService.java
│   │           └── SessionService.java
│   └── resources/
│       └── application.properties
```

## API Documentation

### Authentication
```http
POST /api/auth/login
Content-Type: application/json

{
    "username": "admin",
    "password": "password"
}
```

### Get Person Details
```http
GET /api/person
Session-Id: <session-id-from-login>
```

## Security Notes
- Uses AES-256-GCM encryption
- Session-based authentication
- CORS configured for localhost:8000