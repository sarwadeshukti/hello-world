package api.config;

import api.service.SessionService;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

public class SessionAuthenticationFilter extends AbstractPreAuthenticatedProcessingFilter {

    private final SessionService sessionService;

    public SessionAuthenticationFilter(SessionService sessionService) {
        this.sessionService = sessionService;
        // Set a simple authentication manager that always returns true for our session token
        super.setAuthenticationManager(authentication -> {
            authentication.setAuthenticated(true);
            return authentication;
        });
    }

    @Override
    protected Object getPreAuthenticatedPrincipal(HttpServletRequest request) {
        String sessionId = request.getHeader("Session-Id");

        if (sessionId != null && sessionService.isValidSession(sessionId)) {
            String username = sessionService.getUsernameFromSessionId(sessionId);
            return username;
        }

        logger.debug("No valid session found");
        return null;
    }

    @Override
    protected Object getPreAuthenticatedCredentials(HttpServletRequest request) {
        return "N/A"; // Return a non-null value
    }
}

