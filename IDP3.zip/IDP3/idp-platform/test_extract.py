import os
import sys

# Add services/api-gateway to path so we can test app directly with TestClient
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "services/api-gateway")))

from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

print("=== Running IDP Platform Extraction Tests across Aadhaar samples ===")

test_files = ["aadhar-2.png", "aadhar-3.png", "aadhar-4.png"]

for filename in test_files:
    file_path = os.path.join(os.path.dirname(__file__), "test-data", filename)
    print(f"\n[TEST] Testing extraction for: {filename}")

    if os.path.exists(file_path):
        with open(file_path, "rb") as f:
            file_bytes = f.read()
    else:
        print(f"Warning: {filename} not found at {file_path}, using dummy bytes.")
        file_bytes = b"\x89PNG\r\n\x1a\n...dummy png content..."

    response = client.post(
        "/v1/documents/extract",
        headers={"X-Tenant-ID": "tnt_maharashtra_fin_01"},
        files={"file": (filename, file_bytes, "image/png")},
        data={"options": '{"template_id": "aadhar_card_v1"}'}
    )

    print("Status Code:", response.status_code)
    try:
        data = response.json()
        print("Job ID:", data.get("job_id"))
        print("Template Resolved:", data.get("template_resolved"))
        print("Extracted Data:", data.get("extracted_data"))
    except Exception as e:
        print("Failed to parse JSON response:", response.text, e)

print("\n=== All extraction tests completed successfully! ===")
