package api.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CryptoServiceTest {
    private CryptoService cryptoService;

    @BeforeEach
    void setUp() {
        cryptoService = new CryptoService();
    }

    @Test
    void testGenerateEncryptionKey() {
        String key = cryptoService.generateEncryptionKey();
        assertNotNull(key);
        assertTrue(key.length() > 0);
    }

    @Test
    void testEncryptionAndDecryption() throws Exception {
        // Given
        String originalData = "Sensitive test data with special chars: !@#$%^&*()";
        String key = cryptoService.generateEncryptionKey();

        // When
        String encrypted = cryptoService.encrypt(originalData, key);
        String decrypted = cryptoService.decrypt(encrypted, key);

        // Then
        assertNotEquals(originalData, encrypted);
        assertEquals(originalData, decrypted);
    }

    @Test
    void testEncryptionWithDifferentKeysProducesDifferentResults() throws Exception {
        // Given
        String data = "Test data";
        String key1 = cryptoService.generateEncryptionKey();
        String key2 = cryptoService.generateEncryptionKey();

        // When
        String encrypted1 = cryptoService.encrypt(data, key1);
        String encrypted2 = cryptoService.encrypt(data, key2);

        // Then
        assertNotEquals(encrypted1, encrypted2);
    }
}