import os
import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_healthz():
    response = client.get("/healthz")
    assert response.status_code == 200
    assert response.json() == {"status": "healthy", "service": "api-gateway"}

def test_extract_document():
    file_content = b"%PDF-1.4 dummy pdf content for testing extraction pipeline..."
    response = client.post(
        "/v1/documents/extract",
        headers={"X-Tenant-ID": "tnt_maharashtra_fin_01"},
        files={"file": ("sample.pdf", file_content, "application/pdf")},
        data={"options": '{"template_id": "agri_loan_multipage_v1"}'}
    )
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "COMPLETED"
    assert data["tenant_id"] == "tnt_maharashtra_fin_01"
    assert "job_id" in data
    assert "extracted_data" in data
    assert "pan_number" in data["extracted_data"]
    assert response.headers.get("X-Job-ID") == data["job_id"]

def test_extract_aadhar_card():
    png_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../test-data/aadhar-2.png"))
    if os.path.exists(png_path):
        with open(png_path, "rb") as f:
            png_bytes = f.read()
    else:
        png_bytes = b"\x89PNG\r\n\x1a\n...dummy png..."

    response = client.post(
        "/v1/documents/extract",
        headers={"X-Tenant-ID": "tnt_maharashtra_fin_01"},
        files={"file": ("aadhar-2.png", png_bytes, "image/png")},
        data={"options": '{"template_id": "aadhar_card_v1"}'}
    )
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "COMPLETED"
    assert "extracted_data" in data
    assert "name" in data["extracted_data"]
    assert "aadhar_no" in data["extracted_data"]
    assert "dob" in data["extracted_data"]

def test_extract_pan_card():
    # Simulated PAN card text content
    pan_doc_bytes = (
        b"%PDF-1.4\n"
        b"INCOME TAX DEPARTMENT GOVT OF INDIA\n"
        b"Permanent Account Number Card\n"
        b"ABCDE1234F\n"
        b"RAHUL SHARMA\n"
        b"RAMESH SHARMA\n"
        b"15/08/1990\n"
    )

    response = client.post(
        "/v1/documents/extract",
        headers={"X-Tenant-ID": "tnt_maharashtra_fin_01"},
        files={"file": ("pan_sample.pdf", pan_doc_bytes, "application/pdf")},
        data={"options": '{"template_id": "pan_card_v1"}'}
    )
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "COMPLETED"
    extracted = data["extracted_data"]
    assert "name" in extracted
    assert "father_name" in extracted
    assert "dob" in extracted
    assert "pan" in extracted
    assert extracted["pan"]["value"] == "ABCDE1234F"
    assert extracted["pan"]["validation_status"] == "PASSED_REGEX"
    assert extracted["dob"]["value"] == "15/08/1990"
    assert extracted["dob"]["validation_status"] == "PASSED_REGEX"

