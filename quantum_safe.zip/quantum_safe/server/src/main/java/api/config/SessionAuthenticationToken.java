package api.config;

import org.springframework.security.authentication.AbstractAuthenticationToken;

public class SessionAuthenticationToken extends AbstractAuthenticationToken {

    private final String username;

    public SessionAuthenticationToken(String username) {
        super(null);
        this.username = username;
        setAuthenticated(true);
    }

    @Override
    public Object getCredentials() {
        return null;
    }

    @Override
    public Object getPrincipal() {
        return username;
    }
}
