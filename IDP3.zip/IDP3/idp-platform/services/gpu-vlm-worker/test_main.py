import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_healthz():
    response = client.get("/healthz")
    assert response.status_code == 200
    assert response.json() == {"status": "healthy", "service": "gpu-vlm-worker"}

def test_process_vlm_inference():
    payload = {
        "job_id": "job_12345",
        "page_number": 2,
        "shm_path": "/dev/shm/idp_page_p2.png",
        "model_id": "Qwen/Qwen2.5-VL-7B-Instruct",
        "provider": "vllm"
    }
    response = client.post("/v1/vlm/infer", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["job_id"] == "job_12345"
    assert data["page_number"] == 2
    assert data["track"] == "GPU_VLM_FP8"
    assert data["status"] == "SUCCESS"
    assert data["vllm_prefix_cache_hit"] is True
    assert "vlm_output" in data
