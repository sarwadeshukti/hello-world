package api.controller;

import api.model.AuthRequest;
import api.model.AuthResponse;
import api.service.SessionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

class AuthControllerTest {
    @Mock
    private SessionService sessionService;

    private AuthController authController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        when(sessionService.createSession(anyString()))
                .thenReturn(new AuthResponse("test-session", "test-key"));
        authController = new AuthController(sessionService);
    }

    @Test
    void testSuccessfulLogin() {
        // Given
        AuthRequest request = new AuthRequest();
        request.setUsername("admin");
        request.setPassword("password");

        // When
        ResponseEntity<AuthResponse> response = authController.login(request);

        // Then
        assertTrue(response.getStatusCode().is2xxSuccessful());
        assertNotNull(response.getBody());
        assertEquals("test-session", response.getBody().getSessionId());
        assertEquals("test-key", response.getBody().getEncryptionKey());
        verify(sessionService).createSession("admin");
    }

    @Test
    void testFailedLogin() {
        // Given
        AuthRequest request = new AuthRequest();
        request.setUsername("wrong");
        request.setPassword("wrong");

        // When
        ResponseEntity<AuthResponse> response = authController.login(request);

        // Then
        assertTrue(response.getStatusCode().is4xxClientError());
        verifyNoInteractions(sessionService);
    }
}
