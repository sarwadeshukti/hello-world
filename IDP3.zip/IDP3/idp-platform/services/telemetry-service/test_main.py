import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_healthz():
    response = client.get("/healthz")
    assert response.status_code == 200
    assert response.json() == {"status": "healthy", "service": "telemetry-service"}

def test_get_job_telemetry():
    job_id = "job_01N8X9P2Q4R6S8T0V2W4Y6Z8A"
    response = client.get(f"/v1/telemetry/jobs/{job_id}?tenant_id=tnt_maharashtra_fin_01")
    assert response.status_code == 200
    data = response.json()
    assert data["job_id"] == job_id
    assert data["tenant_id"] == "tnt_maharashtra_fin_01"
    assert "routing_summary" in data
    assert "overall_timing" in data
    assert "critical_path_steps" in data
